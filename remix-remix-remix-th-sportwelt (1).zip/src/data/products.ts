import { Product, ProductColor } from '../types';

export const STANDARD_COLORS: ProductColor[] = [
  { name: 'Blau', hex: '#2563EB' },
  { name: 'Rot', hex: '#DC2626' },
  { name: 'Schwarz', hex: '#18181B' },
  { name: 'Orange', hex: '#EA580C' },
  { name: 'Grün', hex: '#16A34A' },
  { name: 'Weiß', hex: '#FFFFFF' }
];

export const INITIAL_PRODUCTS: Product[] = [
  // --- HOT DEAL DES TAGES: ADIDAS PERFORMANCE TEAM T-SHIRT PAKET (A LOT OF T-SHIRTS PHOTO) ---
  {
    id: 'deal-adidas-entrada-bundle',
    name: 'adidas Performance Team T-Shirt Bundle (10er Paket)',
    germanName: '10er adidas Performance Team T-Shirt Bundle',
    brand: 'adidas',
    category: 'shirts',
    subcategory: 'Teamsport & Training',
    price: 139.95,
    originalPrice: 249.95,
    discountPercentage: 44,
    badge: '🔥 DEAL DES TAGES',
    rating: 4.9,
    reviewsCount: 148,
    image: 'https://images.unsplash.com/photo-1562157873-818bc0726f68?auto=format&fit=crop&w=900&q=80',
    galleryImages: [
      'https://images.unsplash.com/photo-1562157873-818bc0726f68?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1522778119026-d647f0596c20?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1574629810360-7efbbe195018?auto=format&fit=crop&w=900&q=80'
    ],
    description: 'Special 10-piece adidas Performance training t-shirt package for teams & clubs. Lightweight, moisture-wicking AEROREADY technical fabric designed for daily training sessions.',
    germanDescription: '10er Vereins-Sparpaket der offiziellen adidas Performance Funktions-T-Shirts. Atmungsaktives AEROREADY-Gewebe für optimales Feuchtigkeitsmanagement. Ideal für das Mannschaftstraining mit freier Größen- und Farbwahl.',
    sizes: ['10er Mix: 2xS, 3xM, 3xL, 2xXL', '10er Paket: Gr. M', '10er Paket: Gr. L', '10er Paket: Gr. XL'],
    colors: STANDARD_COLORS,
    inStock: true,
    minQuantity: 10,
    material: '100% Recyceltes Funktions-Polyester (AEROREADY)',
    features: [
      '10 performance t-shirts in one team package',
      'Sweat-wicking adidas AEROREADY technology',
      'Reinforced crewneck and shoulder seams',
      'DTF crest & sponsor print ready'
    ],
    germanFeatures: [
      '10x hochwertige adidas Performance T-Shirts im Paket',
      'AEROREADY-Technologie leitet Schweiß sofort ab',
      'Staffelpreis für Vereine & Teams',
      'Perfekt für DTF-Vereinswappen & Sponsordruck'
    ],
    isFeatured: true,
    isBestSeller: true,
    isDealOfDay: true,
    clubBulkDiscountEligible: true
  },

  // --- BÄLLE SECTION: BALLPAKETE AB 10 STÜCK ---
  {
    id: 'ball-derbystar-10er',
    name: '10er Ballpaket Derbystar Bundesliga Brillant TT (Gr. 5) + Ballsack',
    germanName: '10er Ballpaket Derbystar Bundesliga Brillant TT inkl. Ballsack',
    brand: 'Derbystar',
    category: 'balls',
    subcategory: 'Ballpaket ab 10 Bälle',
    price: 249.00,
    originalPrice: 349.00,
    discountPercentage: 29,
    badge: '⚽ 10er BALLPAKET',
    rating: 5.0,
    reviewsCount: 164,
    image: 'https://images.unsplash.com/photo-1614632537423-1e6c2e7e0aab?auto=format&fit=crop&w=900&q=80',
    galleryImages: [
      'https://images.unsplash.com/photo-1614632537423-1e6c2e7e0aab?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?auto=format&fit=crop&w=900&q=80'
    ],
    description: 'Official 10-ball club package of Derbystar Bundesliga Brillant TT. Dual-bonded hand-stitched construction with diamond textured surface. Includes heavy-duty Derbystar ball sack.',
    germanDescription: 'Offizielles 10er Trainings- & Spielballpaket von Derbystar (Bundesliga-Ausrüster). Handgenäht und thermo-verklebt mit Diamant-Mikrostruktur für präzise Flugbahnen. Inklusive reißfestem Derbystar Ballsack für 12 Bälle.',
    sizes: ['10x Größe 5 (Offizieller Spielball)', '10x Größe 4 (D/E Jugend - 350g)', '10x Größe 3 (Bambini / F-Jugend - 290g)'],
    colors: STANDARD_COLORS,
    inStock: true,
    minQuantity: 10,
    material: 'High-Tech PU Diamantstruktur & Naturlatex-Blase',
    features: [
      'Minimum order: 10 balls per team set',
      'FIFA Basic certified for official league play',
      'Dual Bonded: hand-sewn + heat-sealed',
      'Complimentary Derbystar heavy-duty ball bag included'
    ],
    germanFeatures: [
      'Mindestbestellmenge: 10 Bälle im Set',
      'IMS & FIFA Basic zertifiziert für Meisterschaftsspiele',
      'Dual Bonded: handgenäht und zusätzlich thermo-versiegelt',
      'Inklusive Derbystar Balltasche für 10-12 Bälle'
    ],
    isFeatured: true,
    isBestSeller: true,
    clubBulkDiscountEligible: true
  },
  {
    id: 'ball-adidas-tiro-10er',
    name: '10er Ballpaket adidas Tiro League Match & Training',
    germanName: '10er Ballpaket adidas Tiro League Match & Training (Gr. 5 / 4)',
    brand: 'adidas',
    category: 'balls',
    subcategory: 'Ballpaket ab 10 Bälle',
    price: 219.00,
    originalPrice: 299.00,
    discountPercentage: 27,
    badge: '🔥 TOP SELLER 10er',
    rating: 4.9,
    reviewsCount: 112,
    image: 'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?auto=format&fit=crop&w=900&q=80',
    galleryImages: [
      'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?auto=format&fit=crop&w=900&q=80'
    ],
    description: 'adidas Tiro League 10-ball club package. Seamless thermally bonded TSBE cover delivers true touch and ultra-low water uptake on wet grass.',
    germanDescription: 'Ausbalancierte adidas Tiro Trainings- und Spielbälle im 10er Sparpaket für Vereine. Nahtlose, thermisch geklebte TSBE-Konstruktion für minimale Wasseraufnahme und verlässliche Flugkurven.',
    sizes: ['10x Größe 5 (Senioren / A-B-C Jugend)', '10x Größe 4 (D & E Jugend - 350g)'],
    colors: STANDARD_COLORS,
    inStock: true,
    minQuantity: 10,
    material: '100% TPU thermisch verschweißt',
    features: [
      '10-ball team bundle with ball carrier net',
      'Thermally bonded TSBE technology',
      'Butyl bladder for maximum air retention'
    ],
    germanFeatures: [
      'Mindestbestellmenge: 10 Bälle',
      'Thermisch verklebte nahtlose Oberfläche (TSBE)',
      'Haltbare Butyl-Blase für langen Druckhalt',
      'Inklusive atmungsaktivem Ballnetz'
    ],
    isFeatured: true,
    clubBulkDiscountEligible: true
  },
  {
    id: 'ball-puma-final-10er',
    name: '10er Ballpaket Puma Team Final 21.2 FIFA Quality Matchball',
    germanName: '10er Ballpaket Puma Team Final 21.2 FIFA Quality Matchball',
    brand: 'Puma',
    category: 'balls',
    subcategory: 'Ballpaket ab 10 Bälle',
    price: 259.00,
    originalPrice: 379.00,
    discountPercentage: 32,
    badge: 'FIFA QUALITY MATCH',
    rating: 4.8,
    reviewsCount: 88,
    image: 'https://images.unsplash.com/photo-1552667466-07770ae110d0?auto=format&fit=crop&w=900&q=80',
    galleryImages: [
      'https://images.unsplash.com/photo-1552667466-07770ae110d0?auto=format&fit=crop&w=900&q=80'
    ],
    description: '10-ball set of Puma Team Final 21.2 balls certified by FIFA for competition play. Soft touch PU outer with micro-groove texture.',
    germanDescription: 'Puma Top-Spielbälle im 10er Set mit offiziellem FIFA Quality Gütesiegel. Exzellente Spieleigenschaften auf Naturrasen und modernen Kunstrasenplätzen.',
    sizes: ['10x Größe 5'],
    colors: STANDARD_COLORS,
    inStock: true,
    minQuantity: 10,
    material: 'Multi-Layer PU Schaumstoff & Gummi-Blase',
    features: ['10x FIFA Quality Match Balls', 'Air Lock valve keeps pressure stable'],
    germanFeatures: ['Mindestbestellmenge: 10 Bälle', 'FIFA Quality zertifiziert', 'Air-Lock Ventil für dauerhaften Reifendruck'],
    clubBulkDiscountEligible: true
  },
  {
    id: 'ball-jako-match-10er',
    name: '10er Ballpaket Jako Match 2.0 Trainingsbälle',
    germanName: '10er Ballpaket Jako Match 2.0 Trainingsbälle inkl. Ballnetz',
    brand: 'Jako',
    category: 'balls',
    subcategory: 'Ballpaket ab 10 Bälle',
    price: 189.00,
    originalPrice: 259.00,
    discountPercentage: 27,
    badge: 'VEREINS-HIT 10er',
    rating: 4.9,
    reviewsCount: 142,
    image: 'https://images.unsplash.com/photo-1518091043644-c1d4457512c6?auto=format&fit=crop&w=900&q=80',
    galleryImages: [
      'https://images.unsplash.com/photo-1518091043644-c1d4457512c6?auto=format&fit=crop&w=900&q=80'
    ],
    description: 'The standard training ball package for German amateur squads. 32-panel machine-stitched casing with soft-touch cushioning.',
    germanDescription: 'Der beliebteste Vereinstrainingsball in deutschen Amateurvereinen. 32-Panel Konstruktion für präzises Sprungverhalten und lange Haltbarkeit.',
    sizes: ['10x Größe 5 (Herren & Jugend)', '10x Größe 4 (D-Jugend 350g)', '10x Größe 3 (Bambini 290g)'],
    colors: STANDARD_COLORS,
    inStock: true,
    minQuantity: 10,
    material: 'Strapazierfähiges PU mit 1,0mm Polsterung',
    features: ['10-ball set with heavy net', 'Soft-touch damping for header practice'],
    germanFeatures: ['Mindestmenge: 10 Bälle', 'Abriebfeste Konstruktion', 'Inkl. Jako Ballnetz'],
    clubBulkDiscountEligible: true
  },
  {
    id: 'ball-trainer-set-15er',
    name: '15er Trainer Ballpaket Pro inkl. Ballsack & Doppelhub-Pumpe',
    germanName: '15er Trainer Ballpaket Pro inkl. Ballsack & Doppelhub-Pumpe',
    brand: 'Sportwelt',
    category: 'balls',
    subcategory: 'Ballpaket ab 10 Bälle',
    price: 319.00,
    originalPrice: 449.00,
    discountPercentage: 29,
    badge: '🔥 MEGA 15er VEREINSSET',
    rating: 5.0,
    reviewsCount: 79,
    image: 'https://images.unsplash.com/photo-1552667466-07770ae110d0?auto=format&fit=crop&w=900&q=80',
    galleryImages: [
      'https://images.unsplash.com/photo-1552667466-07770ae110d0?auto=format&fit=crop&w=900&q=80'
    ],
    description: 'Complete 15-ball coaching setup for football coaches. Contains 15 official size 5 match training balls, reinforced ventilated ball duffel, and metal needle pressure pump.',
    germanDescription: 'Komplettes 15er Ausstattungsset für Trainer und Jugendleiter: 15 strapazierfähige Größe 5 Trainingsbälle, 1 robuster Belüftungs-Ballsack für bis zu 16 Bälle und 1 Doppelhub-Ballpumpe mit Manometer.',
    sizes: ['15x Größe 5 (Standard)', '15x Größe 4 (Jugendpaket)'],
    colors: STANDARD_COLORS,
    inStock: true,
    minQuantity: 15,
    material: 'PU High-Density mit verstärkter Butyl-Blase',
    features: ['15 balls + Ball duffel + Dual-stroke air pump', 'Everything a coach needs in one click'],
    germanFeatures: ['15 Bälle + Ballsack + Pumpe', 'Komplettes Trainings-Setup für Vereine', 'Staffel-Vorteilspreis'],
    clubBulkDiscountEligible: true
  },

  // --- KURZE HOSE (FUSSBALLER MATCH & TRAININGSSHORTS HERREN & JUGEND) SECTION ---
  {
    id: 'short-adidas-squadra',
    name: 'adidas Squadra 21 Match & Training Shorts (Herren & Jugend Fußballer)',
    germanName: 'adidas Squadra 21 Fußball Match- & Trainingsshorts (Herren & Jugend)',
    brand: 'adidas',
    category: 'kurzehose',
    subcategory: 'Kurze Hosen / Shorts',
    price: 14.95,
    originalPrice: 23.00,
    discountPercentage: 35,
    badge: 'FUSSBALLER MATCH-SHORT',
    rating: 4.9,
    reviewsCount: 248,
    image: 'https://img01.ztat.net/article/spp-media-p1/4dc4db3b51174afcb4c30fc17c24f5ef/d6ea700ac3a946f489a3b7508cfdb75a.jpg?imwidth=800&filter=packshot',
    galleryImages: [
      'https://img01.ztat.net/article/spp-media-p1/4dc4db3b51174afcb4c30fc17c24f5ef/d6ea700ac3a946f489a3b7508cfdb75a.jpg?imwidth=800&filter=packshot',
      '/images/kurzhose/kurzhose-5.jpg'
    ],
    description: 'adidas Squadra 21 match shorts engineered specifically for football players. Lightweight, moisture-wicking AEROREADY fabric with elastic waistband and inner drawcord. Built without inner brief to comfortably wear with player compression tights.',
    germanDescription: 'Speziell für Fußballspieler (Herren & Jugend) konzipierte Match- und Trainingsshorts. Leichtes, schweißableitendes AEROREADY-Material für maximale Bewegungsfreiheit bei Sprints, Schüssen und Grätschen. Ohne störenden Innenslip – ideal kombinierbar mit Funktions-Tight.',
    sizes: ['116', '128', '140', '152', '164', 'S', 'M', 'L', 'XL', 'XXL', '3XL'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: '100% Recyceltes Hochleistungs-Polyester (AEROREADY)',
    features: ['Engineered for football players', 'Moisture-absorbing AEROREADY', 'Elastic waistband with inner drawcord', 'No inner slip for slider tights'],
    germanFeatures: [
      'Für Herren & Jugend Fußballer optimierter Schnitt',
      'Atmungsaktives AEROREADY Gewebe',
      'Reißfest bei harten Zweikämpfen auf Natur- und Kunstrasen',
      'Ohne Innenslip für maximale Beinfreiheit'
    ],
    isFeatured: true,
    clubBulkDiscountEligible: true
  },
  {
    id: 'short-nike-park-iii',
    name: 'Nike Dri-FIT Park III Spieler-Shorts (Herren & Jugend)',
    germanName: 'Nike Dri-FIT Park III Fußball Match- & Trainingsshorts',
    brand: 'Nike',
    category: 'kurzehose',
    subcategory: 'Kurze Hosen / Shorts',
    price: 13.95,
    originalPrice: 19.99,
    discountPercentage: 30,
    badge: 'DRI-FIT PRO FUSSBALL',
    rating: 4.8,
    reviewsCount: 194,
    image: 'https://cdn02.plentymarkets.com/shnuxd70ih03/item/images/43661885/full/nike-trainingshose.jpg',
    galleryImages: [
      'https://cdn02.plentymarkets.com/shnuxd70ih03/item/images/43661885/full/nike-trainingshose.jpg',
      '/images/kurzhose/kurzhose-4.jpg'
    ],
    description: 'Nike Dri-FIT Park III knit match shorts for football players. Fast-drying technical fabric keeps football athletes dry through tough 90-minute league matches.',
    germanDescription: 'Die bewährte Nike Matchshort für Fußballer: Feuchtigkeitsableitende Dri-FIT Faser hält Spieler über 90 Minuten trocken. Belüfteter Mesh-Bund für optimalen Sitz ohne Verrutschen.',
    sizes: ['128', '140', '152', '164', 'S', 'M', 'L', 'XL', 'XXL'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: '100% Polyester Dri-FIT',
    features: ['Dri-FIT soccer technology', 'Mesh-lined athletic waistband', 'Ergonomic football inseam'],
    germanFeatures: [
      'Dri-FIT Feuchtigkeitstransport für 90 Min. Höchstleistung',
      'Atmungsaktiver Mesh-Bund mit Kordelzug',
      'Klassischer Fußballer-Schnitt für Sprint & Dribbling'
    ],
    clubBulkDiscountEligible: true
  },
  {
    id: 'short-puma-teamfinal',
    name: 'Nike FC Barcelona Match & Training Fußballshorts (Herren & Jugend)',
    germanName: 'Nike FC Barcelona Match- & Trainingsshorts (Herren & Jugend)',
    brand: 'Nike',
    category: 'kurzehose',
    subcategory: 'Kurze Hosen / Shorts',
    price: 19.95,
    originalPrice: 29.95,
    discountPercentage: 33,
    badge: 'FC BARCELONA MATCH',
    rating: 4.9,
    reviewsCount: 132,
    image: 'https://image.sportler.com/image/product/nike/fc_barcelona_short_-_fussballhosen/_d550_nike_fc_barcelona_short_-_fussballhosen_3027766_344428.jpg',
    galleryImages: [
      'https://image.sportler.com/image/product/nike/fc_barcelona_short_-_fussballhosen/_d550_nike_fc_barcelona_short_-_fussballhosen_3027766_344428.jpg',
      '/images/kurzhose/kurzhose-6.jpg'
    ],
    description: 'Official Nike FC Barcelona match and training shorts for football players. High-performance Dri-FIT moisture-wicking technology with elastic waistband and inner drawcord.',
    germanDescription: 'Offizielle Nike FC Barcelona Fußball Match- und Trainingsshorts. Hochfunktionelles Dri-FIT Material hält Spieler kühl und trocken bei intensiven Spielphasen.',
    sizes: ['128', '140', '152', '164', 'S', 'M', 'L', 'XL', 'XXL'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: '100% Recyceltes Nike Dri-FIT Performance Polyester',
    features: ['Official FC Barcelona branding', 'Dri-FIT moisture regulation', 'Athletic match cut'],
    germanFeatures: [
      'Dri-FIT Feuchtigkeitsregulierung',
      'Offizielle Details und Wappen-Stickerei',
      'Scheuerfeste Flachnähte an den Innenschenkeln'
    ],
    clubBulkDiscountEligible: true
  },
  {
    id: 'short-jako-manchester',
    name: 'Jako Manchester 2.0 Fußball-Spielhose (Herren & Jugend)',
    germanName: 'Jako Manchester 2.0 Fußballhose ohne Innenslip',
    brand: 'Jako',
    category: 'kurzehose',
    subcategory: 'Kurze Hosen / Shorts',
    price: 11.95,
    originalPrice: 17.99,
    discountPercentage: 33,
    badge: 'VEREINS-KLASSIKER',
    rating: 4.9,
    reviewsCount: 220,
    image: 'https://www.sportworld24.de/media/image/d3/38/bb/4400_096_08_1.jpg',
    galleryImages: [
      'https://www.sportworld24.de/media/image/d3/38/bb/4400_096_08_1.jpg',
      '/images/kurzhose/kurzhose-2.jpg'
    ],
    description: 'Durable Jako Manchester 2.0 match shorts for male and youth football squads. Hard-wearing Keep Dry micro-interlock fabric without inner slip.',
    germanDescription: 'Die beliebteste Amateur-Fußballhose in Deutschland: Extrem reißfestes Interlock-Gewebe für Herren- und Jugendmannschaften. Hält auch harten Grätschen auf Kunstrasen problemlos stand.',
    sizes: ['116', '128', '140', '152', '164', 'S', 'M', 'L', 'XL', 'XXL', '3XL'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: '100% Polyester-Interlock (Keep Dry)',
    features: ['Keep Dry micro-mesh', 'Wide elastic waistband', 'Tough football interlock weave'],
    germanFeatures: [
      'Keep Dry Funktion für trockene Beine',
      'Reißfestes Interlock-Gewebe gegen Zupfen & Grätschen',
      'Staffelpreise für ganze Fußballmannschaften'
    ],
    clubBulkDiscountEligible: true
  },
  {
    id: 'short-uhlsport-center',
    name: 'Uhlsport Center Basic & Essential Tech Shorts (Herren & Jugend)',
    germanName: 'Uhlsport Essential Tech & Center Fußball-Spielhose',
    brand: 'Uhlsport',
    category: 'kurzehose',
    subcategory: 'Kurze Hosen / Shorts',
    price: 12.95,
    originalPrice: 18.99,
    discountPercentage: 31,
    badge: 'MATCH READY',
    rating: 4.8,
    reviewsCount: 145,
    image: 'https://www.tennistown.de/images/uhlsport_Sporthose_Essential_Tech_Short_100529001_1.jpg',
    galleryImages: [
      'https://www.tennistown.de/images/uhlsport_Sporthose_Essential_Tech_Short_100529001_1.jpg',
      '/images/kurzhose/kurzhose-3.jpg'
    ],
    description: 'Uhlsport Essential Tech football shorts with adjustable drawcord and durable polyester weave. Ideal for club match kits and weekly training sessions.',
    germanDescription: 'Klassische Uhlsport Spielhose für Feldspieler im Herren- und Jugendbereich. Verstellbarer Kordelzug im Elastikbund, formbeständig und pflegeleicht nach schlammigen Spielen.',
    sizes: ['128', '140', '152', '164', 'S', 'M', 'L', 'XL', 'XXL'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: '100% Polyester Smartbreathe FIT',
    features: ['Smartbreathe FIT breathability', 'Adjustable waistband with cord', 'Club kit compatible'],
    germanFeatures: [
      'Atmungsaktives Smartbreathe FIT Gewebe',
      'Reißfeste Seitennähte für Zweikämpfe',
      'Passend zu allen Uhlsport Trikotsätzen'
    ],
    clubBulkDiscountEligible: true
  },
  {
    id: 'short-erima-squad',
    name: 'Erima Squad Fußball Trainings- & Spielshorts (Herren & Jugend)',
    germanName: 'Erima Squad Fußball-Shorts (Herren & Jugend)',
    brand: 'Erima',
    category: 'kurzehose',
    subcategory: 'Kurze Hosen / Shorts',
    price: 15.95,
    originalPrice: 24.99,
    discountPercentage: 36,
    badge: 'ERIMA SQUAD',
    rating: 4.8,
    reviewsCount: 89,
    image: 'https://intersport-de.imgdn.net/fsi/server?type=image&effects=Pad(cc,ffffff),Matte(FFFFFF)&width=800&height=800&source=marktplatz%2Fproduktiv%2F169%2F0%2F109608_V.jpg',
    galleryImages: [
      'https://intersport-de.imgdn.net/fsi/server?type=image&effects=Pad(cc,ffffff),Matte(FFFFFF)&width=800&height=800&source=marktplatz%2Fproduktiv%2F169%2F0%2F109608_V.jpg',
      '/images/kurzhose/kurzhose-1.jpg'
    ],
    description: 'Erima Squad team shorts tailored for football players. Featuring quick-drying moisture transport and side mesh inserts for extra cooling during hot match days.',
    germanDescription: 'Erima Squad Fußballhose für Training und Meisterschaftsspiele. Schnelltrocknendes Funktionsmaterial mit seitlichen Mesh-Einsätzen für beste Belüftung im vollen Sprint.',
    sizes: ['128', '140', '152', '164', 'S', 'M', 'L', 'XL', 'XXL'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: '100% Polyester SquadTech',
    features: ['SquadTech moisture transfer', 'Ventilated side mesh inserts', 'Reinforced waistband'],
    germanFeatures: [
      'Seitliche Mesh-Zonen für maximale Luftzirkulation',
      'Optimierte Passform für Fußballspieler',
      'Farblich abgestimmt auf alle Erima Vereinstrikots'
    ],
    clubBulkDiscountEligible: true
  },

  // --- TORWARTHOSE SECTION ---
  {
    id: 'gk-uhlsport-ergonomic-long',
    name: 'Uhlsport Ergonomic Gepolsterte Torwarthose lang',
    germanName: 'Uhlsport Ergonomic Gepolsterte Torwarthose lang',
    brand: 'Uhlsport',
    category: 'torwarthose',
    subcategory: 'Torwarthosen',
    price: 34.95,
    originalPrice: 49.95,
    discountPercentage: 30,
    badge: '🧤 PRO POLSTER',
    rating: 4.9,
    reviewsCount: 94,
    image: 'https://i.otto.de/i/otto/a7759310-9a4d-560f-9226-d0e58f439b13?$responsive_ft2$',
    galleryImages: [
      'https://i.otto.de/i/otto/a7759310-9a4d-560f-9226-d0e58f439b13?$responsive_ft2$',
      '/images/torwarthose/torwarthose-otto.jpg'
    ],
    description: 'Long goalkeeping pants engineered with ergonomic dual-density EVA hip and knee padding. Abrasion-resistant outer fabric prevents friction burns on hard ground and turf.',
    germanDescription: 'Lange Profi-Torwarthose mit ergonomischer EVA-Dämpfung an Hüfte und Knien. Speziell verstärktes Obermaterial schützt vor Schürfwunden auf Kunstrasen und Hartplätzen.',
    sizes: ['128', '140', '152', '164', 'S', 'M', 'L', 'XL', 'XXL'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: '100% Polyester mit EVA-Schaumstoffpolstern',
    features: ['Dual-density EVA hip and knee pads', 'Ribbed calf inserts for snug boot fit', 'Abrasion-resistant knee zones'],
    germanFeatures: [
      'Dämpfende EVA-Polsterung an Knien und Hüften',
      'Eng anliegende Ripp-Bündchen an den Waden',
      'Abriebfester Schutzstoff für Kunstrasen und Asche',
      'Kordelzug im Elastikbund'
    ],
    isFeatured: true,
    clubBulkDiscountEligible: true
  },
  {
    id: 'gk-jako-striker-short',
    name: 'Jako Striker Gepolsterte Torwartshort',
    germanName: 'Jako Gepolsterte Torwartshort Striker (Hüftschutz)',
    brand: 'Jako',
    category: 'torwarthose',
    subcategory: 'Torwarthosen',
    price: 24.95,
    originalPrice: 34.99,
    discountPercentage: 28,
    badge: 'HÜFTSCHUTZ',
    rating: 4.8,
    reviewsCount: 76,
    image: 'https://tse1.mm.bing.net/th/id/OIP.wby-CRY_sL7Hu5ewfStEsAHaJo?r=0&rs=1&pid=ImgDetMain&o=7&rm=3',
    galleryImages: [
      'https://tse1.mm.bing.net/th/id/OIP.wby-CRY_sL7Hu5ewfStEsAHaJo?r=0&rs=1&pid=ImgDetMain&o=7&rm=3',
      '/images/torwarthose/torwarthose-bing1.webp'
    ],
    description: 'Short goalkeeper pants equipped with flexible side hip impact zones. Allows agile dives without restricting sprint velocity.',
    germanDescription: 'Kurze Torwarthose mit anatomisch geformten Seitenpolstern an den Hüftknochen. Volle Bewegungsfreiheit beim Absprung und Hechten.',
    sizes: ['140', '152', '164', 'S', 'M', 'L', 'XL', 'XXL'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: '100% Polyester & Ergonomischer Schaum',
    features: ['Anatomic hip protection pads', 'Elastic waistband with drawcord'],
    germanFeatures: ['Anatomisch platzierte Hüftpolster', 'Reißfestes Gewebe', 'Schnelltrocknend'],
    clubBulkDiscountEligible: true
  },
  {
    id: 'gk-erima-three-quarter',
    name: 'Erima 3/4 Gepolsterte Torwarthose',
    germanName: 'Erima 3/4 Gepolsterte Torwarthose mit Knieschutz',
    brand: 'Erima',
    category: 'torwarthose',
    subcategory: 'Torwarthosen',
    price: 29.95,
    originalPrice: 44.95,
    discountPercentage: 33,
    badge: '3/4 SCHNITT',
    rating: 4.8,
    reviewsCount: 58,
    image: 'https://tse3.mm.bing.net/th/id/OIP.KQx0696pqqhOOkNsa8ZAZAHaI4?r=0&rs=1&pid=ImgDetMain&o=7&rm=3',
    galleryImages: [
      'https://tse3.mm.bing.net/th/id/OIP.KQx0696pqqhOOkNsa8ZAZAHaI4?r=0&rs=1&pid=ImgDetMain&o=7&rm=3',
      '/images/torwarthose/torwarthose-bing2.webp'
    ],
    description: '3/4 length goalkeeping trousers covering knee and hip regions with impact absorbing cushioning. Perfect for warm match days.',
    germanDescription: '3/4 lange Torwarthose von Erima mit ergonomischem Knie- und Hüftpolster. Der ideale Kompromiss aus Bewegungsfreiheit und Aufprallschutz.',
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: '100% Polyester',
    features: ['3/4 length cut', 'Knee and hip padding'],
    germanFeatures: ['3/4 Länge für perfekten Knieschutz', 'Atmungsaktiv', 'Formstabile Polster'],
    clubBulkDiscountEligible: true
  },

  // --- HANDSCHOE (TORWARTHANDSCHUHE) SECTION ---
  {
    id: 'glove-precision-fusion-x-3d',
    name: 'Precision Fusion X 3D Pro Negative Cut Torwarthandschuhe',
    germanName: 'Precision Fusion X 3D Negativ Pro Torwarthandschuhe',
    brand: 'Precision',
    category: 'handschoe',
    subcategory: 'Handschuhe',
    price: 49.95,
    originalPrice: 69.95,
    discountPercentage: 29,
    badge: '3D PRO NEGATIVE',
    rating: 4.9,
    reviewsCount: 142,
    image: '/images/gloves/precision-fusion-x-3d-pro.jpg',
    galleryImages: [
      '/images/gloves/precision-fusion-x-3d-pro.jpg',
      'https://taurussports.ch/wp-content/uploads/1017262_gr-600x600.jpg'
    ],
    description: 'Precision Fusion X 3D Pro match gloves featuring 4mm German latex foam, negative cut construction for a snug second-skin fit, and embossed 3D punching control zones.',
    germanDescription: 'Precision Fusion X 3D Pro Torwarthandschuh für anspruchsvolle Spiel- und Trainingssituationen. Griffiger deutscher Latex-Haftschaum, enger Negativ-Schnitt für direktes Ballgefühl und 3D-geprägte Faustzone.',
    sizes: ['Gr. 7', 'Gr. 7.5', 'Gr. 8', 'Gr. 8.5', 'Gr. 9', 'Gr. 9.5', 'Gr. 10', 'Gr. 10.5', 'Gr. 11'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: '4mm Deutscher Haftschaum & 3D Geprägter Latex-Handrücken',
    features: ['4mm German latex palm', 'Negative cut for precision fit', '3D embossed punch zone', 'Full latex wrist strap'],
    germanFeatures: [
      '4mm Deutscher Profi-Latex für herausragenden Allwetter-Grip',
      'Negativschnitt (Innennaht) für direktes und präzises Fanggefühl',
      '3D-geprägte Faustzone für kontrollierte Faustabwehr',
      'Umlaufende Latex-Bandage für sicheren Handgelenkshalt'
    ],
    isFeatured: true,
    clubBulkDiscountEligible: true
  },
  {
    id: 'glove-torspieler-stealth-contact',
    name: 'Torspieler Stealth Contact Fingersave Match Torwarthandschuhe',
    germanName: 'Torspieler Stealth Contact Fingersave Torwarthandschuhe',
    brand: 'Torspieler',
    category: 'handschoe',
    subcategory: 'Handschuhe',
    price: 59.95,
    originalPrice: 89.95,
    discountPercentage: 33,
    badge: '🧤 FINGERSAVE PRO',
    rating: 5.0,
    reviewsCount: 168,
    image: '/images/gloves/torspieler-stealth-contact.jpg',
    galleryImages: [
      '/images/gloves/torspieler-stealth-contact.jpg',
      'https://www.torspielertraining.de/wp-content/uploads/2017/03/Handschuhe-1.jpeg'
    ],
    description: 'Torspieler Stealth Contact goalkeeper gloves with integrated Fingersave finger protection system. 4mm Contact latex palm provides extreme grip and shock absorption in wet and dry conditions.',
    germanDescription: 'Torspieler Stealth Contact Torwarthandschuhe mit integrierten Fingersave-Protektoren zum Schutz vor Überstreckung der Finger. 4mm Contact Profi-Latex für überragenden Grip bei allen Witterungen und breite elastische Doppelbandage.',
    sizes: ['Gr. 7.5', 'Gr. 8', 'Gr. 8.5', 'Gr. 9', 'Gr. 9.5', 'Gr. 10', 'Gr. 10.5', 'Gr. 11'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: '4mm Contact Profi-Latex & Integrierte Fingersave-Protektoren',
    features: ['4mm Contact professional latex palm', 'Integrated Fingersave protection system', 'Ergonomic palm cut', 'Elastic wrist support strap'],
    germanFeatures: [
      'Integrierter Fingersave-Fingerschutz an 4 Fingern gegen Umknicken',
      '4mm Contact Profi-Haftschaum für extreme Ballhaftung',
      'Dämpfende Latex-Oberhand für kraftvolle Faustabwehr',
      'Doppelt gewickelte Handgelenksbandage mit Klettverschluss'
    ],
    isFeatured: true,
    clubBulkDiscountEligible: true
  },
  {
    id: 'glove-precision-fusion-x-giga',
    name: 'Precision Fusion X Giga Grip Hybrid Torwarthandschuhe',
    germanName: 'Precision Fusion X Giga Grip Hybrid Torwarthandschuhe',
    brand: 'Precision',
    category: 'handschoe',
    subcategory: 'Handschuhe',
    price: 44.95,
    originalPrice: 64.95,
    discountPercentage: 31,
    badge: 'GIGA GRIP HYBRID',
    rating: 4.8,
    reviewsCount: 115,
    image: '/images/gloves/precision-fusion-x-giga.jpg',
    galleryImages: [
      '/images/gloves/precision-fusion-x-giga.jpg',
      'https://taurussports.ch/wp-content/uploads/1017265_gr.jpg'
    ],
    description: 'Precision Fusion X Giga Grip match gloves with hybrid cut technology combining roll finger and negative cut for superior catching surface and comfort.',
    germanDescription: 'Precision Fusion X Giga Grip Torwarthandschuhe mit modernem Hybrid-Schnitt. Kombiniert Rollfinger- und Innennaht-Konstruktion für maximale Fangfläche und herausragende Dämpfung bei harten Schüssen.',
    sizes: ['Gr. 6', 'Gr. 7', 'Gr. 8', 'Gr. 8.5', 'Gr. 9', 'Gr. 9.5', 'Gr. 10', 'Gr. 11'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: 'Giga Grip Profi-Latex & Atmungsaktiver Coolair-Körper',
    features: ['Giga Grip 4mm latex', 'Hybrid cut (Roll/Negative)', 'Coolair breathable fabric', 'Wrap-around latex strap'],
    germanFeatures: [
      '4mm Giga Grip Latex für hohe Klebkraft bei Trockenheit und Regen',
      'Hybrid-Schnitt für maximierten Ballkontakt an den Fingerkuppen',
      'Atmungsaktive Coolair-Gewebeeinsätze für kühle Hände',
      'Latex-verstärkte Handgelenksfixierung'
    ],
    clubBulkDiscountEligible: true
  },
  {
    id: 'glove-gripmode-air-blue',
    name: 'Gripmode Air Blue Hybrid Pro Torwarthandschuhe',
    germanName: 'Gripmode Air Blue Hybrid Pro Torwarthandschuhe (Cyan)',
    brand: 'Gripmode',
    category: 'handschoe',
    subcategory: 'Handschuhe',
    price: 69.95,
    originalPrice: 89.95,
    discountPercentage: 22,
    badge: 'GRIPTEC HYBRID',
    rating: 4.9,
    reviewsCount: 198,
    image: '/images/gloves/gripmode-air-blue-hybrid.jpg',
    galleryImages: [
      '/images/gloves/gripmode-air-blue-hybrid.jpg',
      'https://m.media-amazon.com/images/I/81BcwK8scfS._AC_SX679_.jpg'
    ],
    description: 'Gripmode Air Blue Hybrid match glove featuring 4mm Griptec professional latex palm, breathable Air-Mesh body, and silicone punching elements.',
    germanDescription: 'Gripmode Air Blue Hybrid Profi-Torwarthandschuhe. Ausgestattet mit 4mm Griptec Latex für kompromisslosen Grip, leichter Air-Mesh Rückhand und Silikon-Punching-Elementen für maximale Ballkontrolle.',
    sizes: ['Gr. 7', 'Gr. 7.5', 'Gr. 8', 'Gr. 8.5', 'Gr. 9', 'Gr. 9.5', 'Gr. 10', 'Gr. 10.5', 'Gr. 11'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: '4mm Griptec Profi-Latex & Ultraleichtes Air-Mesh',
    features: ['4mm Griptec latex palm', 'Hybrid negative cut', 'Air-Mesh temperature regulation', 'Silicone punch zone'],
    germanFeatures: [
      '4mm Griptec Profi-Haftschaum für extremen Grip in jeder Spielsituation',
      'Hybrid-Negativschnitt für passgenauen Sitz an den Fingern',
      'Silikon-Punchzone für kontrolliertes Wegfausten',
      'Atmungsaktives Air-Mesh Gewebe gegen Hitzestau'
    ],
    isFeatured: true,
    clubBulkDiscountEligible: true
  },
  {
    id: 'glove-adidas-predator-pro-lemon',
    name: 'adidas Predator Pro Match Torwarthandschuhe (Lucid Lemon)',
    germanName: 'adidas Predator Pro Match Torwarthandschuhe (Lucid Lemon / Solar Blue)',
    brand: 'adidas',
    category: 'handschoe',
    subcategory: 'Handschuhe',
    price: 89.95,
    originalPrice: 129.95,
    discountPercentage: 31,
    badge: 'URG 2.0 MATCH PRO',
    rating: 5.0,
    reviewsCount: 224,
    image: '/images/gloves/adidas-predator-pro-lemon.jpg',
    galleryImages: [
      '/images/gloves/adidas-predator-pro-lemon.jpg',
      'https://m.media-amazon.com/images/I/81NjS6YtC5L._AC_SL1500_.jpg'
    ],
    description: 'adidas Predator Pro match gloves engineered with URG 2.0 latex palm, High-Definition Grip silicon elements on knit backhand, and negative cut construction.',
    germanDescription: 'adidas Predator Pro Torwarthandschuhe in der auffälligen Lucid Lemon / Solar Blue Edition. URG 2.0 Haftschaum für Profi-Halt, gestrickte Rückhand mit High-Definition Grip-Elementen und engem Negativschnitt.',
    sizes: ['Gr. 7.5', 'Gr. 8', 'Gr. 8.5', 'Gr. 9', 'Gr. 9.5', 'Gr. 10', 'Gr. 10.5', 'Gr. 11'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: 'URG 2.0 Latex & High-Definition Grip Gestrickte Rückhand',
    features: ['URG 2.0 professional match latex', 'High-Definition silicone grip zone', 'Negative cut', 'Strapless knitted entry'],
    germanFeatures: [
      'URG 2.0 Match-Latex mit optimaler Dämpfung bei Hochgeschwindigkeitsschüssen',
      'High-Definition Silikonelemente auf der gestrickten Oberhand für präzise Faustabwehr',
      'Eng anliegender Negativschnitt (Innennaht)',
      'Elastischer Bund ohne Klettriemen für uneingeschränkte Handgelenksfreiheit'
    ],
    isFeatured: true,
    clubBulkDiscountEligible: true
  },
  {
    id: 'glove-attono-resistance-fingersave',
    name: 'Attono Resistance Fingersave Pro Torwarthandschuhe',
    germanName: 'Attono Resistance Fingersave Torwarthandschuhe (Neonorange)',
    brand: 'Attono',
    category: 'handschoe',
    subcategory: 'Handschuhe',
    price: 39.95,
    originalPrice: 59.95,
    discountPercentage: 33,
    badge: 'FINGERSAVE PROTECTION',
    rating: 4.8,
    reviewsCount: 134,
    image: '/images/gloves/attono-resistance-fingersave.jpg',
    galleryImages: [
      '/images/gloves/attono-resistance-fingersave.jpg',
      'https://i.otto.de/i/otto/81a8fa05-2c91-4ef9-9741-a550e1e197c4/attono-torwarthandschuhe-attono-torwarthandschuhe-resistance-fingersave-torwart-handschuhe.jpg'
    ],
    description: 'Attono Resistance Fingersave goalkeeper gloves with 4-finger removable protection spines, durable latex palm with abrasion zone, and elastic wrist wrap.',
    germanDescription: 'Attono Resistance Fingersave Torwarthandschuhe mit 4-Finger-Fingerschutz gegen Umknicken. Robuster Spezial-Latexbelag mit abriebfester Dämpfungszone für Natur- und Kunstrasenplätze.',
    sizes: ['Gr. 6', 'Gr. 7', 'Gr. 8', 'Gr. 8.5', 'Gr. 9', 'Gr. 9.5', 'Gr. 10', 'Gr. 10.5', 'Gr. 11'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: 'Soft Grip Latex mit Abrieb-Verstärkung & Fingerschutz-Stäbe',
    features: ['Fingersave finger protection', 'Abrasion resistant palm zone', 'Soft latex cushioning', 'Full elastic bandage'],
    germanFeatures: [
      'Integrierter 4-Finger-Schutz gegen schmerzhaftes Überstrecken',
      'Abriebfeste Spezialzone am Handballen für Kunstrasen und Hartplatz',
      'Gedämpfter Soft-Latex für sicheres Zupacken',
      'Klassischer Klettverschluss mit elastischem Einschlupf'
    ],
    clubBulkDiscountEligible: true
  },
  {
    id: 'glove-gripmode-classic-blue-hybrid',
    name: 'Gripmode Classic Blue Hybrid (Strive Series) Torwarthandschuhe',
    germanName: 'Gripmode Classic Blue Hybrid Torwarthandschuhe (Strive Pro)',
    brand: 'Gripmode',
    category: 'handschoe',
    subcategory: 'Handschuhe',
    price: 74.95,
    originalPrice: 94.95,
    discountPercentage: 21,
    badge: 'STRIVE PRO SERIES',
    rating: 4.9,
    reviewsCount: 184,
    image: '/images/gloves/gripmode-classic-blue-hybrid.jpg',
    galleryImages: [
      '/images/gloves/gripmode-classic-blue-hybrid.jpg',
      'https://gripmode.com/cdn/shop/files/Striveproductmikeweb_4500x.jpg?v=1721746705'
    ],
    description: 'Gripmode Classic Blue Hybrid from the Strive Series. Premium 4mm Griptec German latex, neoprene body with embossed silicone strike elements, and elastic bandage.',
    germanDescription: 'Gripmode Classic Blue Hybrid aus der Strive-Serie. 4mm Griptec Profi-Latex für extreme Haftung, Neopren-Körper mit geprägten Silikon-Faustzonen und ergonomischer Hybrid-Schnitt.',
    sizes: ['Gr. 7', 'Gr. 7.5', 'Gr. 8', 'Gr. 8.5', 'Gr. 9', 'Gr. 9.5', 'Gr. 10', 'Gr. 10.5', 'Gr. 11'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: '4mm Griptec Profi-Latex & Ergonomischer Neopren-Body',
    features: ['4mm Griptec latex', 'Hybrid cut with wrapped thumb', 'Neoprene body', '360 degree wrist closure'],
    germanFeatures: [
      '4mm Griptec Profi-Haftschaum mit unvergleichlicher Klebkraft',
      'Hybrid-Schnitt mit Daumen-Ummantelung für maximale Ballkontaktfläche',
      'Atmungsaktiver Neopren-Körper schützt und stützt die Hand',
      '360° elastische Bandage für stabilen Handgelenksitz'
    ],
    isFeatured: true,
    clubBulkDiscountEligible: true
  },
  {
    id: 'glove-attono-power-block-ii',
    name: 'Attono Power Block II Fingersave Torwarthandschuhe',
    germanName: 'Attono Power Block II Fingersave Torwarthandschuhe (Super Fit)',
    brand: 'Attono',
    category: 'handschoe',
    subcategory: 'Handschuhe',
    price: 34.95,
    originalPrice: 49.95,
    discountPercentage: 30,
    badge: 'POWER BLOCK FINGERSAVE',
    rating: 4.8,
    reviewsCount: 156,
    image: '/images/gloves/attono-power-block-2.jpg',
    galleryImages: [
      '/images/gloves/attono-power-block-2.jpg',
      'https://i.otto.de/i/otto/92569ce7-cc7e-4e0c-a75e-704f3d889fce/attono-torwarthandschuhe-attono-torwarthandschuhe-power-block-ii-fingersave-torwart-handschuhe.jpg'
    ],
    description: 'Attono Power Block II goalkeeper gloves featuring Fingersave finger protection system, Super Fit cut, shock-absorbing latex backhand, and full elastic wrist bandage.',
    germanDescription: 'Attono Power Block II Torwarthandschuhe mit bewährtem Fingersave-Schutzsystem an 4 Fingern. Super Fit Passform, griffige Dämpfungsschaum-Handfläche und breite Klettverschluss-Bandage.',
    sizes: ['Gr. 5 (Jugend)', 'Gr. 6', 'Gr. 7', 'Gr. 8', 'Gr. 8.5', 'Gr. 9', 'Gr. 9.5', 'Gr. 10', 'Gr. 10.5'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: 'Grip Foam Dämpfungsschaum & Fingersave-Schutzelemente',
    features: ['Fingersave finger protection spines', 'Super Fit ergonomic cut', 'Embossed latex backhand', 'Full bandage wrist strap with velcro'],
    germanFeatures: [
      'Integrierte Fingersave-Versteifungen gegen Umknicken der Finger',
      'Super Fit Passform für natürliche Handhaltung beim Fangen',
      'Strapazierfähiger Grip-Foam für Langlebigkeit im Vereinstraining',
      'Breite elastische Handgelenksbandage mit Klettverschluss'
    ],
    clubBulkDiscountEligible: true
  },

  // --- TRAININGSANZUG (TRACKSUITS) SECTION ---
  {
    id: 'anzug-nike-sportswear-basic',
    name: 'Nike Sportswear Herren-Trainingsanzug (Woven Basic)',
    germanName: 'Nike Sportswear Herren-Trainingsanzug (Woven Basic)',
    brand: 'Nike',
    category: 'trainingsanzug',
    subcategory: 'Trainingsanzüge',
    price: 59.95,
    originalPrice: 79.99,
    discountPercentage: 25,
    badge: 'NIKE SPORTSWEAR',
    rating: 4.9,
    reviewsCount: 178,
    image: '/images/trainingsanzug/nike-sportswear-tracksuit.jpg',
    galleryImages: [
      '/images/trainingsanzug/nike-sportswear-tracksuit.jpg',
      'https://www.engelhorn.de/dw/image/v2/AALR_PRD/on/demandware.static/-/Sites-engelhorn-master-plattform/default/dw285fa3fa/images/P10/10/41/6M/V1074037W/engelhorn-Nike-Sportswear-Herren-Trainingsanzug-Vorderansicht-V1074037W-v1.jpg'
    ],
    description: 'Nike Sportswear woven track suit complete set. Features lightweight, durable taffeta fabric with breathable mesh lining, full-zip track jacket with stand-up collar, and matching athletic pants with elastic waistband.',
    germanDescription: 'Nike Sportswear Herren-Trainingsanzug im klassischen 2-teiligen Set: Leichter, strapazierfähiger Taft-Stoff mit atmungsaktivem Mesh-Futter. Jacke mit durchgehendem Reißverschluss und Stehkragen, abgestimmte Hose mit elastischem Bund und seitlichen Eingrifftaschen.',
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: '100% Nylon / Taft mit atmungsaktivem Mesh-Innenfutter',
    features: ['2-piece jacket and pants set', 'Woven taffeta fabric with mesh lining', 'Stand-up collar with full zip', 'Elastic cuffs and hem'],
    germanFeatures: [
      '2-teiliges Set: Trainingsjacke & passende Sporthose',
      'Gewebtes Taft-Material mit Mesh-Futter für optimale Belüftung',
      'Stehkragen und durchgehender Front-Reißverschluss',
      'Ideal für Training, Freizeit und Vereinsauftritt'
    ],
    isFeatured: true,
    isBestSeller: true,
    clubBulkDiscountEligible: true
  },
  {
    id: 'anzug-adidas-tiro23-league',
    name: 'adidas Tiro 23 League Training Tracksuit Komplettset',
    germanName: 'adidas Tiro 23 League Training Tracksuit Komplettset (Jacke + Hose)',
    brand: 'adidas',
    category: 'trainingsanzug',
    subcategory: 'Trainingsanzüge',
    price: 54.95,
    originalPrice: 85.00,
    discountPercentage: 35,
    badge: 'TIRO 23 LEAGUE',
    rating: 4.9,
    reviewsCount: 162,
    image: '/images/trainingsanzug/adidas-tiro-23-league-tracksuit.jpg',
    galleryImages: [
      '/images/trainingsanzug/adidas-tiro-23-league-tracksuit.jpg',
      'https://desportivo.de/media/catalog/product/cache/57b8e234991f6234dda7ae3007d3556c/a/d/adidas-komplet-meski-tiro-23-league-training-track-top-hs3501-hs7230-1.jpg'
    ],
    description: 'adidas Tiro 23 League training tracksuit set (Track Top HS3501 + Training Pants HS7230). Built with moisture-absorbing AEROREADY fabric, ribbed stand-up collar, slim athletic fit, and ankle zips for quick changes.',
    germanDescription: 'adidas Tiro 23 League Trainingsanzug-Komplettset (Jacke HS3501 & Hose HS7230). Feuchtigkeitsabsorbierendes AEROREADY Material, klassische 3-Streifen Optik, schmaler Schnitt und praktische Knöchel-Reißverschlüsse für schnelles An- und Ausziehen mit Fußballschuhen.',
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: '100% Recyceltes Polyester (AEROREADY)',
    features: ['AEROREADY sweat-wicking technology', 'Full zip jacket with stand-up collar', 'Slim fit pants with ankle zippers', 'Official teamwear set'],
    germanFeatures: [
      'AEROREADY Technologie hält dich trocken und fokussiert',
      'Jacke mit Stehkragen und Reißverschlusstaschen',
      'Schmal zulaufende Beinform mit Reißverschluss an den Knöcheln',
      'Offizielle Teamsport-Kollektion für Vereine'
    ],
    isFeatured: true,
    clubBulkDiscountEligible: true
  },
  {
    id: 'anzug-adidas-entrada22-presentation',
    name: 'adidas Entrada 22 Präsentationsanzug Komplettset',
    germanName: 'adidas Entrada 22 Präsentationsanzug Komplettset (Jacke + Hose)',
    brand: 'adidas',
    category: 'trainingsanzug',
    subcategory: 'Trainingsanzüge',
    price: 49.95,
    originalPrice: 69.95,
    discountPercentage: 29,
    badge: 'ENTRADA 22 SET',
    rating: 4.8,
    reviewsCount: 134,
    image: '/images/trainingsanzug/adidas-entrada-22-presentation-tracksuit.jpg',
    galleryImages: [
      '/images/trainingsanzug/adidas-entrada-22-presentation-tracksuit.jpg',
      'https://desportivo.de/media/catalog/product/cache/57b8e234991f6234dda7ae3007d3556c/k/o/komplet-meski-adidas-entrada-22-presentation-hb0571-h57533-1.jpg'
    ],
    description: 'adidas Entrada 22 presentation suit complete package (Presentation Jacket HB0571 + Track Pants H57533). Crisp woven moisture-managing fabric, clean minimalist design ideal for club badge cresting and matchday travel.',
    germanDescription: 'adidas Entrada 22 Präsentationsanzug Komplettset (Jacke HB0571 & Hose H57533). Strapazierfähiges, schnelltrocknendes AEROREADY Gewebe. Das zeitlose, cleane Design bietet optimale freie Flächen für Vereinswappen, Sponsorenprints und Spielernummern.',
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: '100% Recyceltes Polyester (AEROREADY Ripstop)',
    features: ['Complete 2-piece presentation suit', 'AEROREADY moisture management', 'Ideal for club badges & DTF printing', 'Zipped pockets on jacket and trousers'],
    germanFeatures: [
      'Komplettes 2-teiliges Präsentationsset',
      'AEROREADY Material leitet Schweiß ab',
      'Große freie Veredelungsflächen für DTF-Vereinsdruck',
      'Reißverschlusstaschen für Smartphone und Wertsachen'
    ],
    clubBulkDiscountEligible: true
  },

  // --- HOODIES (FUSSBALL TRAININGS-HOODIES & WARMUP) SECTION ---
  {
    id: 'hoodie-jako-base',
    name: 'Jako Fußball Hoodie BASE (Schwarz)',
    germanName: 'Jako Fußball Hoodie BASE (Schwarz - Bio-Baumwolle)',
    brand: 'Jako',
    category: 'hoodies',
    subcategory: 'Hoodies',
    price: 34.95,
    originalPrice: 49.99,
    discountPercentage: 30,
    badge: 'JAKO BASE HOODIE',
    rating: 4.9,
    reviewsCount: 148,
    image: '/images/hoodies/jako-hoodie-base-black.jpg',
    galleryImages: [
      '/images/hoodies/jako-hoodie-base-black.jpg',
      'https://www.engelhorn.de/dw/image/v2/AALR_PRD/on/demandware.static/-/Sites-engelhorn-master-plattform/default/dw60a528f0/images/P10/11/53/7K/V1075851K/engelhorn-Jako-Fussball-Hoodie-BASE-Vorderansicht-V1075851K-v1.jpg'
    ],
    description: 'Jako BASE hooded sweatshirt in black. Crafted predominantly from certified soft organic cotton with a comfortable French terry inner lining. Features a kangaroo pouch pocket and adjustable drawstring hood.',
    germanDescription: 'Jako BASE Fußball Kapuzensweat in Schwarz: Klassisch, sportlich und extrem bequem. Gefertigt aus weicher Bio-Baumwolle mit aufgerauter Innenseite, aufgesetzter Kängurutasche und Kapuze mit Kordelzug.',
    sizes: ['128', '140', '152', '164', 'S', 'M', 'L', 'XL', 'XXL', '3XL'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: '70% Bio-Baumwolle, 30% Recyceltes Polyester',
    features: ['Soft certified organic cotton blend', 'Kangaroo pouch pocket for cold hands', 'Lined hood with drawstring', 'Pre-shrunk against washing shrinkage'],
    germanFeatures: [
      'Gekämmte Bio-Baumwolle mit weichem Griff',
      'Vorgewaschen gegen Einlaufen bei Vereinswäschen',
      'Aufgesetzte Kängurutasche für warme Hände',
      'Ideal für Veredelung mit Vereinslogo & Spielernummer'
    ],
    isFeatured: true,
    clubBulkDiscountEligible: true
  },
  {
    id: 'hoodie-jako-base-anthracite',
    name: 'Jako Fußball Hoodie BASE (Anthrazit Melange)',
    germanName: 'Jako Fußball Hoodie BASE (Anthrazit Melange)',
    brand: 'Jako',
    category: 'hoodies',
    subcategory: 'Hoodies',
    price: 34.95,
    originalPrice: 49.99,
    discountPercentage: 30,
    badge: 'JAKO BASE MELANGE',
    rating: 4.9,
    reviewsCount: 126,
    image: '/images/hoodies/jako-hoodie-base-anthracite.jpg',
    galleryImages: [
      '/images/hoodies/jako-hoodie-base-anthracite.jpg',
      'https://www.engelhorn.de/dw/image/v2/AALR_PRD/on/demandware.static/-/Sites-engelhorn-master-plattform/default/dw6cbaf231/images/P10/11/53/7K/V1075851F/engelhorn-partner-Jako-Fussball-Hoodie-BASE-Vorderansicht-V1075851F-v1.jpg'
    ],
    description: 'Jako BASE hooded sweatshirt in stylish anthracite melange colorway. Soft pre-shrunk cotton blend with contrasting drawstring and ribbed cuffs.',
    germanDescription: 'Jako BASE Fußball Kapuzensweat in moderner Anthrazit-Melange-Optik. Strapazierfähig, formstabil und mit kuscheliger Innenseite für kühlere Trainingstage und die Ersatzbank.',
    sizes: ['128', '140', '152', '164', 'S', 'M', 'L', 'XL', 'XXL', '3XL'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: '60% Bio-Baumwolle, 34% Recyceltes Polyester, 6% Viskose',
    features: ['Melange fabric finish', 'Ribbed cuffs and waistband', 'Contrasting drawcord hood'],
    germanFeatures: [
      'Edle Melange-Struktur mit weichem Tragegefühl',
      'Rippbündchen an Ärmeln und Bund für optimalen Sitz',
      'Zertifizierte nachhaltige Materialien'
    ],
    isFeatured: true,
    clubBulkDiscountEligible: true
  },
  {
    id: 'hoodie-classic-organic',
    name: 'Premium Team Kapuzenpullover Organic (Klassik Hoodie)',
    germanName: 'Premium Team Kapuzenpullover Organic (Klassik Hoodie)',
    brand: 'Sportwelt',
    category: 'hoodies',
    subcategory: 'Hoodies',
    price: 32.95,
    originalPrice: 44.95,
    discountPercentage: 27,
    badge: 'PREMIUM ORGANIC',
    rating: 4.8,
    reviewsCount: 94,
    image: '/images/hoodies/hoodie-396428.jpg',
    galleryImages: [
      '/images/hoodies/hoodie-396428.jpg',
      'https://thumblr.uniid.it/product/396428/7067ed8cac8c.jpg'
    ],
    description: 'Heavyweight organic cotton team hoodie with double-layer hood, brushed fleece interior, and reinforced seams for maximum durability.',
    germanDescription: 'Hochwertiger Team-Kapuzenpullover aus schwerer Bio-Baumwolle mit doppellagiger Kapuze und flauschig angerauter Innenseite. Perfekt geeignet für den Vereinsauftritt abseits des Platzes.',
    sizes: ['S', 'M', 'L', 'XL', 'XXL', '3XL'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: '80% Bio-Baumwolle, 20% Recyceltes Polyester (320 g/m² Heavy Fleece)',
    features: ['320 g/m² heavyweight fleece', 'Double-lined hood', 'Kangaroo pocket with reinforced seams'],
    germanFeatures: [
      'Schwere 320 g/m² Qualität für langlebige Formbeständigkeit',
      'Doppellagige Kapuze mit Metallösen und breiter Kordel',
      'Optimal für Wappendruck und Vereinsstickereien'
    ],
    clubBulkDiscountEligible: true
  },
  {
    id: 'hoodie-adidas-team19',
    name: 'adidas Team 19 Fußball Trainings-Hoodie (DW6860)',
    germanName: 'adidas Team 19 Fußball Trainings-Hoodie (DW6860)',
    brand: 'adidas',
    category: 'hoodies',
    subcategory: 'Hoodies',
    price: 38.95,
    originalPrice: 55.00,
    discountPercentage: 29,
    badge: 'ADIDAS TEAM 19',
    rating: 4.9,
    reviewsCount: 152,
    image: '/images/hoodies/adidas-t19-hoodie-dw6860.jpg',
    galleryImages: [
      '/images/hoodies/adidas-t19-hoodie-dw6860.jpg',
      'https://content.directsoccer.co.uk/upload/img/o/49f7d-dw6860_app_photo_front-center_transparent.jpg'
    ],
    description: 'Official adidas Team 19 Hoody (DW6860) designed for active football drills, pitch warmups, and travel. Crafted with breathable, quick-drying performance fabric and signature adidas badge of sport.',
    germanDescription: 'Offizieller adidas Team 19 Fußball-Trainingshoodie (Modell DW6860). Atmungsaktives, feuchtigkeitsableitendes Performance-Material hält die Muskeln vor dem Anpfiff warm und trocken. Kängurutasche und elastische Bündchen.',
    sizes: ['128', '140', '152', '164', 'S', 'M', 'L', 'XL', 'XXL'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: '100% Recyceltes Polyester (Climacool Moisture-Wicking)',
    features: ['Official adidas DW6860 Team 19 model', 'Climacool breathability and sweat-wicking', 'Kangaroo pocket and ribbed hem'],
    germanFeatures: [
      'Offizielles adidas Team 19 Modell (Art.-Nr. DW6860)',
      'Schnelltrocknendes Funktionsmaterial für das Fußballtraining',
      'Kängurutasche und bequeme Kapuze für windige Spieltage',
      'Klassisches adidas Badge of Sport auf der Brust'
    ],
    isFeatured: true,
    clubBulkDiscountEligible: true
  },

  // --- PULLOVERS & SWEATSHIRTS (FUSSBALL TRAININGSTOP DRILL TOPS) SECTION ---
  {
    id: 'pullover-adidas-tiro-kf3415',
    name: 'adidas Tiro League Crew Sweatshirt (KF3415)',
    germanName: 'adidas Tiro League Crew Sweatshirt (KF3415)',
    brand: 'adidas',
    category: 'pullovers',
    subcategory: 'Pullover & Sweatshirts',
    price: 34.95,
    originalPrice: 49.99,
    discountPercentage: 30,
    badge: 'TIRO LEAGUE CREW',
    rating: 4.9,
    reviewsCount: 168,
    image: '/images/pullovers/pullover-kf3415.jpg',
    galleryImages: [
      '/images/pullovers/pullover-kf3415.jpg',
      'https://www.cortexpower.de/out/pictures/generated/product/1/473_508_75/kf3415_1_apparel_photography_front_center_view_white.jpg'
    ],
    description: 'adidas Tiro League crew neck football sweatshirt (Modell KF3415). Soft cotton-blend fabric with ribbed collar and cuffs for everyday team comfort and training.',
    germanDescription: 'adidas Tiro League Rundhals-Trainingspullover (Modell KF3415). Weiches, strapazierfähiges Baumwoll-Mischgewebe mit elastischem Rundhalsausschnitt und Rippbündchen für optimalen Tragekomfort auf dem Platz und in der Freizeit.',
    sizes: ['128', '140', '152', '164', 'S', 'M', 'L', 'XL', 'XXL'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: '70% Baumwolle, 30% Recyceltes Polyester',
    features: ['Original adidas KF3415 Tiro model', 'Ribbed crewneck and cuffs', 'Soft cotton-poly blend'],
    germanFeatures: [
      'Offizielles adidas Modell (Art.-Nr. KF3415)',
      'Rundhalsausschnitt mit elastischem Rippkragen',
      'Ideal für Vereinsveredelung und Freizeitauftritt'
    ],
    isFeatured: true,
    clubBulkDiscountEligible: true
  },
  {
    id: 'pullover-adidas-squadra21-blue',
    name: 'adidas Squadra 21 Sweatshirt Blau (GT6639)',
    germanName: 'adidas Squadra 21 Sweatshirt Königsblau (GT6639)',
    brand: 'adidas',
    category: 'pullovers',
    subcategory: 'Pullover & Sweatshirts',
    price: 31.95,
    originalPrice: 45.00,
    discountPercentage: 29,
    badge: 'SQUADRA 21 TEAM',
    rating: 4.9,
    reviewsCount: 142,
    image: '/images/pullovers/adidas-squadra-21-sweatshirt-blau-gt6639.png',
    galleryImages: [
      '/images/pullovers/adidas-squadra-21-sweatshirt-blau-gt6639.png',
      'https://www.soccerboots.de/cdn-cgi/image/format=webp,width=1400/media/54/53/47/1727841617/adidas-squadra-21-sweatshirt-blau-gt6639-teamsport-front.png'
    ],
    description: 'adidas Squadra 21 crew sweatshirt in team royal blue (GT6639). Featuring sweat-managing AEROREADY fabric and classic shoulder stripes.',
    germanDescription: 'adidas Squadra 21 Trainingspullover in Königsblau (Art.-Nr. GT6639). Ausgestattet mit feuchtigkeitsabsorbierendem AEROREADY Material, Streifendesign an den Ärmeln und bequemer Passform.',
    sizes: ['128', '140', '152', '164', 'S', 'M', 'L', 'XL', 'XXL'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: '70% Baumwolle, 30% Recyceltes Polyester-Fleece (AEROREADY)',
    features: ['adidas Squadra 21 GT6639 model', 'AEROREADY moisture management', 'Ribbed cuffs and hem'],
    germanFeatures: [
      'Offizieller adidas Squadra 21 Teamsport-Sweater',
      'AEROREADY Gewebe leitet Schweiß ab',
      'Große freie Brustfläche für Vereinswappen und Sponsorendruck'
    ],
    isFeatured: true,
    clubBulkDiscountEligible: true
  },
  {
    id: 'pullover-adidas-squadra21-black',
    name: 'adidas Squadra 21 Sweater Heren (Schwarz / Weiß)',
    germanName: 'adidas Squadra 21 Sweater Heren (Schwarz / Weiß)',
    brand: 'adidas',
    category: 'pullovers',
    subcategory: 'Pullover & Sweatshirts',
    price: 31.95,
    originalPrice: 45.00,
    discountPercentage: 29,
    badge: 'SQUADRA 21 BLACK',
    rating: 4.8,
    reviewsCount: 135,
    image: '/images/pullovers/adidas-squadra-21-sweater-heren.jpg',
    galleryImages: [
      '/images/pullovers/adidas-squadra-21-sweater-heren.jpg',
      'https://cdn.plutosport.com/a/ProductMedia/Adidas/P.ADI.SWE.8007/Adidas-Squadra-21-Sweater-Heren_14.jpg?profile=product_page_image_medium&33'
    ],
    description: 'adidas Squadra 21 men crew sweater in classic black and white. Comfortable fleece blend designed for cold pre-game warmups and team travel.',
    germanDescription: 'adidas Squadra 21 Herren-Sweater im klassischen Schwarz-Weiß-Design. Weiches Fleece-Gewebe hält Fußballer vor dem Anpfiff und bei der Anreise angenehm warm.',
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: '70% Baumwolle, 30% Recyceltes Polyester-Fleece',
    features: ['Regular fit crew sweater', 'Ribbed collar and cuffs', 'Classic 3-Stripes shoulder detailing'],
    germanFeatures: [
      'Klassischer Schnitt für maximale Bewegungsfreiheit',
      'Rippstrickbündchen an Ärmeln und Saum',
      'Langlebiges Material für den dauerhaften Trainingsbetrieb'
    ],
    clubBulkDiscountEligible: true
  },
  {
    id: 'pullover-adidas-tiro-trainingstop',
    name: 'adidas Tiro Fußball Trainingstop 1/4-Zip Drill Top',
    germanName: 'adidas Tiro Fußball Trainingstop 1/4-Zip Drill Top',
    brand: 'adidas',
    category: 'pullovers',
    subcategory: 'Pullover & Sweatshirts',
    price: 34.95,
    originalPrice: 49.99,
    discountPercentage: 30,
    badge: '1/4-ZIP DRILL TOP',
    rating: 4.9,
    reviewsCount: 156,
    image: '/images/pullovers/pullover-sportshop.jpg',
    galleryImages: [
      '/images/pullovers/pullover-sportshop.jpg',
      'https://cdn.sport-shop.pl/p/v1/big/4e604cf1312ea0ff88974ad72363cac6.jpg'
    ],
    description: 'adidas Tiro 1/4 zip football training top drill pullover. Aerodynamic slim cut with high stand-up collar and moisture-absorbing AEROREADY.',
    germanDescription: 'adidas Tiro Fußball Trainingstop mit 1/4-Reißverschluss und Stehkragen. Aerodynamische Passform mit elastischen Daumenschlaufen für intensive Trainingseinheiten auf dem Rasen.',
    sizes: ['128', '140', '152', '164', 'S', 'M', 'L', 'XL', 'XXL'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: '100% Recyceltes Funktions-Polyester (AEROREADY)',
    features: ['1/4 front zip with stand-up collar', 'Thumb loops at cuffs', 'AEROREADY moisture management'],
    germanFeatures: [
      '1/4-Front-Reißverschluss für flexible Belüftung',
      'Stehkragen schützt vor kaltem Wind',
      'AEROREADY Technologie für trockenen Tragekomfort'
    ],
    isFeatured: true,
    clubBulkDiscountEligible: true
  },

  // --- SCHINBEINSCHOE (SCHIENBEINSCHONER) SECTION ---
  {
    id: 'shinguard-nike-mercurial-lite',
    name: 'Nike Mercurial Lite Schienbeinschoner (inkl. Sleeves)',
    germanName: 'Nike Mercurial Lite Schienbeinschoner (inkl. Kompressionssleeves)',
    brand: 'Nike',
    category: 'schinbeinschoe',
    subcategory: 'Schienbeinschoner',
    price: 19.95,
    originalPrice: 27.99,
    discountPercentage: 29,
    badge: '🛡️ BESTSELLER SCHONER',
    rating: 4.9,
    reviewsCount: 245,
    image: 'https://images.unsplash.com/photo-1517466787929-bc90951d0974?auto=format&fit=crop&w=900&q=80',
    galleryImages: [
      'https://images.unsplash.com/photo-1517466787929-bc90951d0974?auto=format&fit=crop&w=900&q=80'
    ],
    description: 'Ultra-lightweight Nike Mercurial Lite shin guards paired with breathable compression sleeves to prevent shifting during high-speed sprints and heavy tackles.',
    germanDescription: 'Ultraleichte Nike Mercurial Lite Schienbeinschoner inklusive atmungsaktiver Kompressionsmanschetten. Flaches Profil dämpft Stöße ab, ohne die Beweglichkeit einzuschränken.',
    sizes: ['XS (bis 140 cm)', 'S (140 - 160 cm)', 'M (160 - 175 cm)', 'L (175 - 190 cm)', 'XL (ab 190 cm)'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: 'K-Resin Schale & EVA-Dämpfungsschaum',
    features: [
      'Low-profile shell for lightweight impact protection',
      'Dense EVA foam backing absorbs shock',
      'Breathable, seamless compression sleeves included'
    ],
    germanFeatures: [
      'Flache Hartschale für federleichten Aufprallschutz',
      'Dichter EVA-Schaumstoff zur Schockabsorption',
      'Inklusive nahtloser Kompressionsüberzüge (Sleeves)',
      'Anatomische Rechts-/Links-Passform'
    ],
    isFeatured: true,
    isBestSeller: true,
    clubBulkDiscountEligible: true
  },
  {
    id: 'shinguard-uhlsport-carbon-flex',
    name: 'Uhlsport Carbon Flex Pro Shinguard ultraleicht',
    germanName: 'Uhlsport Carbon Flex Pro Shinguard ultraleicht',
    brand: 'Uhlsport',
    category: 'schinbeinschoe',
    subcategory: 'Schienbeinschoner',
    price: 24.95,
    originalPrice: 39.95,
    discountPercentage: 37,
    badge: 'CARBON FLEX',
    rating: 4.8,
    reviewsCount: 86,
    image: 'https://images.unsplash.com/photo-1517466787929-bc90951d0974?auto=format&fit=crop&w=900&q=80',
    galleryImages: [
      'https://images.unsplash.com/photo-1517466787929-bc90951d0974?auto=format&fit=crop&w=900&q=80'
    ],
    description: 'Uhlsport Carbon Flex shin protectors with carbon-fiber look reinforcement and flexible multi-segment design.',
    germanDescription: 'Uhlsport Carbon Flex Schienbeinschoner mit Carbon-Look Verstärkung und flexibler Segment-Konstruktion für optimale Beinanpassung.',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: 'Carbon-Komposit & EVA Schaumstoff',
    features: ['Multi-segment ergonomic flex', 'Includes compression socks'],
    germanFeatures: ['Flexible Segmentschale passt sich jedem Bein an', 'Inkl. Kompressionsstrümpfe', 'Ultraleichtes Gewicht'],
    clubBulkDiscountEligible: true
  },
  {
    id: 'shinguard-adidas-tiro-match',
    name: 'adidas Tiro Match Schoner mit festem Knöchelschutz',
    germanName: 'adidas Tiro Match Schienbeinschoner mit Knöchelschutz',
    brand: 'adidas',
    category: 'schinbeinschoe',
    subcategory: 'Schienbeinschoner',
    price: 16.95,
    originalPrice: 22.00,
    discountPercentage: 23,
    badge: 'KNÖCHELSCHUTZ',
    rating: 4.8,
    reviewsCount: 130,
    image: 'https://images.unsplash.com/photo-1517466787929-bc90951d0974?auto=format&fit=crop&w=900&q=80',
    galleryImages: [
      'https://images.unsplash.com/photo-1517466787929-bc90951d0974?auto=format&fit=crop&w=900&q=80'
    ],
    description: 'adidas Tiro Match guards with attached ankle sleeve protection. Ideal for youth players and defensive players seeking ankle security.',
    germanDescription: 'Robuste adidas Tiro Schienbeinschoner mit integriertem, festem Knöchelschutz. Besonders beliebt bei Jugendspielern und defensiven Zweikämpfern.',
    sizes: ['S (140-160cm)', 'M (160-175cm)', 'L (175-190cm)', 'XL (ab 190cm)'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: 'Hartschale & Gepolsterter Knöchelstrumpf',
    features: ['Attached padded ankle guard', 'Hook-and-loop strap closure'],
    germanFeatures: [
      'Fester Knöchelschutz schützt vor Tritten gegen die Knöchel',
      'Verstellbarer Klettverschluss oben',
      'EVA-Dämpfungsrücken'
    ],
    clubBulkDiscountEligible: true
  },

  // --- FUßBALL-STUTZEN & SOCKEN (MATCH- & TRAININGSSOCKEN) SECTION ---
  {
    id: 'sock-jako-lazio',
    name: 'Jako Lazio Fußball-Stutzenstrümpfe (Herren & Jugend)',
    germanName: 'Jako Lazio Fußball-Stutzenstrümpfe',
    brand: 'Jako',
    category: 'socks',
    subcategory: 'Stutzen & Socken',
    price: 6.95,
    originalPrice: 9.99,
    discountPercentage: 30,
    badge: 'VEREINS-STUTZEN',
    rating: 4.9,
    reviewsCount: 164,
    image: 'https://www.mprosports.com/en/large/SOCKS-JAKO-LAZIO,-WHITE-BLACK.-5(43-46)-i-v-3866-00-5.jpg',
    galleryImages: [
      'https://www.mprosports.com/en/large/SOCKS-JAKO-LAZIO,-WHITE-BLACK.-5(43-46)-i-v-3866-00-5.jpg',
      '/images/socks/socks-jako.jpg'
    ],
    description: 'Jako Lazio match football socks engineered with cotton footbed and elastic rib ankle support for superior shin-guard retention during full matches.',
    germanDescription: 'Klassische Jako Lazio Fußball-Stutzenstrümpfe mit elastischem Ripp-Bündchen und feuchtigkeitsabsorbierendem Baumwollfuß. Rutschfester Sitz für Schienbeinschoner bei Zweikämpfen und 90-Minuten-Einsätzen.',
    sizes: ['1 (27-30)', '2 (31-34)', '3 (35-38)', '4 (39-42)', '5 (43-46)'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: '97% Polyester, 3% Elasthan mit Baumwoll-Fußteil',
    features: ['Ribbed ankle compression', 'Cotton foot cushion', 'Anti-slip shin guard fit'],
    germanFeatures: [
      'Elastische Ripp-Struktur an Fessel und Wade',
      'Gepolsterter Baumwollfuß verhindert Blasenbildung',
      'Passend zu allen Jako Vereins-Trikotsätzen'
    ],
    isFeatured: true,
    clubBulkDiscountEligible: true
  },
  {
    id: 'sock-erima-six-wings',
    name: 'Erima Six Wings Pro Stutzenstrümpfe (Herren & Jugend)',
    germanName: 'Erima Six Wings High-Performance Stutzenstrümpfe',
    brand: 'Erima',
    category: 'socks',
    subcategory: 'Stutzen & Socken',
    price: 7.95,
    originalPrice: 11.99,
    discountPercentage: 34,
    badge: 'SIX WINGS PERFORMANCE',
    rating: 4.8,
    reviewsCount: 112,
    image: 'https://aiilo.ch/media/image/product/222229/lg/erima-six-wings-socks.png',
    galleryImages: [
      'https://aiilo.ch/media/image/product/222229/lg/erima-six-wings-socks.png',
      '/images/socks/socks-erima.png'
    ],
    description: 'Erima Six Wings high-performance football socks featuring anatomical left/right toe construction, plush sole damping, and calf compression.',
    germanDescription: 'Erima Six Wings High-Performance Fußballstutzen mit ergonomischer Links-/Rechts-Passform. Dämpfende Plüschzone an Ferse und Ballen sowie elastische Dehnzone für perfekte Fixierung der Schienbeinschoner.',
    sizes: ['0 (29-32)', '1 (31-34)', '2 (35-38)', '3 (39-42)', '4 (43-46)', '5 (47-50)'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: '92% Polyester, 6% Elasthan, 2% Polyamid',
    features: ['Anatomical left/right footbed', 'Shock-absorbing plush sole', 'Durable heel & toe reinforcement'],
    germanFeatures: [
      'Ergonomische Links- und Rechts-Passform',
      'Plüsch-Verstärkung an Sohle und Ferse für maximale Dämpfung',
      'Atmungsaktive Belüftungskanäle am Spann'
    ],
    clubBulkDiscountEligible: true
  },
  {
    id: 'sock-nike-matchfit',
    name: 'Nike MatchFit Kniehohe Dri-FIT Fußballstutzen',
    germanName: 'Nike MatchFit Kniehohe Fußballstutzen (Dri-FIT)',
    brand: 'Nike',
    category: 'socks',
    subcategory: 'Stutzen & Socken',
    price: 12.95,
    originalPrice: 17.99,
    discountPercentage: 28,
    badge: 'DRI-FIT MATCHFIT',
    rating: 4.9,
    reviewsCount: 185,
    image: 'https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/5e6bfe3c-8553-475e-88b1-4c35d01f191c/matchfit-football-knee-high-socks-1HSw1l.png',
    galleryImages: [
      'https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/5e6bfe3c-8553-475e-88b1-4c35d01f191c/matchfit-football-knee-high-socks-1HSw1l.png',
      '/images/socks/socks-nike.png'
    ],
    description: 'Nike MatchFit knee-high football socks equipped with Dri-FIT moisture-wicking technology, anatomical arch support, and targeted cushioning.',
    germanDescription: 'Nike MatchFit professionelle Knie-Fußballstutzen mit schweißableitender Dri-FIT Technologie. Gezielte Dämpfung in stark beanspruchten Fußbereichen und komprimierendes Fußgewölbeband für rutschfesten Halt.',
    sizes: ['S (34-38)', 'M (38-42)', 'L (42-46)', 'XL (46-50)'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: '92% Polyester, 5% Baumwolle, 3% Elasthan (Dri-FIT)',
    features: ['Nike Dri-FIT moisture control', 'Targeted foot strike cushioning', 'Dynamic arch band'],
    germanFeatures: [
      'Dri-FIT Technologie leitet Schweiß sofort nach außen ab',
      'Gezielte Polsterung an Ballen und Ferse für Aufpralldämpfung',
      'Dynamisches Fußrücken-Band für stabilen, festen Sitz'
    ],
    isFeatured: true,
    clubBulkDiscountEligible: true
  },

  // --- FOOTBALL T-SHIRTS & JERSEYS (TRIKOTS & SHIRTS - ALLE TOP MARKEN) ---
  {
    id: 'shirt-erima-squad-jersey',
    name: 'Erima Squad Teamsport Functional T-Shirt',
    germanName: 'Erima Squad Teamsport Funktions T-Shirt',
    brand: 'Erima',
    category: 'shirts',
    subcategory: 'Teamsport & Training',
    price: 14.95,
    originalPrice: 29.99,
    discountPercentage: 50,
    badge: '🔥 -50% SPORTDEAL',
    rating: 4.9,
    reviewsCount: 184,
    image: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=900&q=80',
    galleryImages: [
      'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1522778119026-d647f0596c20?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?auto=format&fit=crop&w=900&q=80'
    ],
    description: 'Official Erima high-performance technical team shirt with Quick-Dry moisture management and ergonomic flatlock seams. High UVP reduction for club teams.',
    germanDescription: 'Offizielles Erima Teamsport Hochleistungs-Funktionsshirt mit Quick-Dry Feuchtigkeitsregulierung, formstabilem Rundhals und 50% Preisvorteil für Vereine.',
    sizes: ['116', '128', '140', '152', '164', 'S', 'M', 'L', 'XL', 'XXL', '3XL'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: '100% Recyceltes QuickDry Polyester (140 g/m²)',
    features: [
      'Erima Quick Dry finish for optimal temperature regulation',
      'Reinforced shoulder elements for long-lasting team wear',
      'Heat-resistant fabric for easy crest & sponsor flocking',
      'Available in 10 team colors from youth 116 to adult 3XL'
    ],
    germanFeatures: [
      'Erima Quick-Dry Technologie für optimales Körperklima',
      'Formstabiler Rundhalskragen & Reißfeste Teamsport-Nähte',
      'Hitzebeständiger Stoff für perfekte Beflockung (Wappen & Sponsor)',
      'In 10 Vereinsfarben von Kindergrößen (116) bis 3XL sofort ab Lager lieferbar'
    ],
    isFeatured: true,
    isBestSeller: true,
    clubBulkDiscountEligible: true
  },
  {
    id: 'shirt-nike-dri-fit-park',
    name: 'Nike Dri-FIT Park VII Match & Training Tee',
    germanName: 'Nike Dri-FIT Park VII Funktions T-Shirt & Trikot',
    brand: 'Nike',
    category: 'shirts',
    subcategory: 'Teamsport & Training',
    price: 14.95,
    originalPrice: 29.99,
    discountPercentage: 50,
    badge: '🔥 -50% NIKE DEAL',
    rating: 5.0,
    reviewsCount: 216,
    image: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=900&q=80',
    galleryImages: [
      'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?auto=format&fit=crop&w=900&q=80'
    ],
    description: 'Nike Dri-FIT Park VII training jersey made from 100% recycled polyester mesh. Keeps you cool, dry, and focused during matches and team sessions.',
    germanDescription: 'Nike Dri-FIT Park VII Trainingstrikot aus schweißableitendem Funktionsmaterial. Bietet uneingeschränkte Bewegungsfreiheit auf dem Fußballplatz.',
    sizes: ['116', '128', '140', '152', '164', 'S', 'M', 'L', 'XL', 'XXL', '3XL'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: '100% Recyceltes Nike Dri-FIT Polyester',
    features: [
      'Nike Dri-FIT technology keeps sweat off your skin',
      'Mesh back panel adds extra breathability',
      'Slim fit for a tailored matchday feel',
      'Direct supplier pricing with 50% discount'
    ],
    germanFeatures: [
      'Nike Dri-FIT Technologie für trockenen Tragekomfort',
      'Mesh-Einsatz am Rücken für verbesserte Belüftung',
      'Körpernahe sportliche Passform für optimales Spielgefühl',
      'In 10 Farben lieferbar - Ideal für Vereinsausstattungen'
    ],
    isFeatured: true,
    isBestSeller: true,
    clubBulkDiscountEligible: true
  },
  {
    id: 'shirt-adidas-aeroready-tiro',
    name: 'adidas Entrada / Tiro AEROREADY Functional Shirt',
    germanName: 'adidas Tiro / Entrada AEROREADY Funktions T-Shirt',
    brand: 'adidas',
    category: 'shirts',
    subcategory: 'Teamsport & Training',
    price: 14.95,
    originalPrice: 29.99,
    discountPercentage: 50,
    badge: '🔥 -50% ADIDAS DEAL',
    rating: 4.9,
    reviewsCount: 198,
    image: 'https://images.unsplash.com/photo-1522778119026-d647f0596c20?auto=format&fit=crop&w=900&q=80',
    galleryImages: [
      'https://images.unsplash.com/photo-1522778119026-d647f0596c20?auto=format&fit=crop&w=900&q=80'
    ],
    description: 'adidas high-performance AEROREADY technical shirt. Iconic 3-stripes styling and ultra-lightweight fabric engineered for matchdays and training.',
    germanDescription: 'adidas Hochleistungs-AEROREADY Trikot mit den klassischen 3-Streifen. Schnelle Feuchtigkeitsaufnahme für Höchstleistungen im Vereinsfußball.',
    sizes: ['116', '128', '140', '152', '164', 'S', 'M', 'L', 'XL', 'XXL', '3XL'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: '100% Recyceltes adidas AEROREADY Polyester',
    features: [
      'AEROREADY absorbs moisture and keeps you dry',
      'Smooth interlock fabric for durability',
      'Ribbed crewneck collar'
    ],
    germanFeatures: [
      'AEROREADY leitet Feuchtigkeit sofort ab',
      'Strapazierfähiges Interlock-Gewebe für harte Trainingseinheiten',
      'Klassischer Rundhalsausschnitt mit Rippbündchen'
    ],
    isFeatured: true,
    isBestSeller: true,
    clubBulkDiscountEligible: true
  },
  {
    id: 'shirt-puma-drycell-teamliga',
    name: 'Puma teamLIGA dryCELL Functional Shirt',
    germanName: 'Puma teamLIGA dryCELL Funktions T-Shirt',
    brand: 'Puma',
    category: 'shirts',
    subcategory: 'Teamsport & Training',
    price: 14.95,
    originalPrice: 29.99,
    discountPercentage: 50,
    badge: '🔥 -50% PUMA DEAL',
    rating: 4.8,
    reviewsCount: 142,
    image: 'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?auto=format&fit=crop&w=900&q=80',
    galleryImages: [
      'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?auto=format&fit=crop&w=900&q=80'
    ],
    description: 'Puma teamLIGA athletic jersey with dryCELL tech and forward-angled side seams for maximum athletic freedom.',
    germanDescription: 'Puma teamLIGA Vereinstrikot mit dryCELL Technologie und vorverlegten Seitennähten für maximale Bewegungsfreiheit bei Sprints.',
    sizes: ['116', '128', '140', '152', '164', 'S', 'M', 'L', 'XL', 'XXL', '3XL'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: '100% dryCELL Performance Polyester',
    features: [
      'dryCELL moisture-wicking properties',
      'Contrast colored mesh inserts on sleeves',
      'Regular athletic fit'
    ],
    germanFeatures: [
      'dryCELL Technologie für hochgradigen Feuchtigkeitstransport',
      'Atmungsaktive Mesh-Einsätze an den Ärmeln',
      'Robuster Stoff ideal für Trikotsatz-Beflockung'
    ],
    isFeatured: true,
    clubBulkDiscountEligible: true
  },
  {
    id: 'shirt-jako-challenge-jersey',
    name: 'Jako Challenge / Center Teamsport Funktionsshirt',
    germanName: 'Jako Challenge Teamsport Funktions T-Shirt',
    brand: 'Jako',
    category: 'shirts',
    subcategory: 'Teamsport & Training',
    price: 14.95,
    originalPrice: 29.99,
    discountPercentage: 50,
    badge: '🔥 -50% JAKO DEAL',
    rating: 5.0,
    reviewsCount: 230,
    image: 'https://images.unsplash.com/photo-1518091043644-c1d4457512c6?auto=format&fit=crop&w=900&q=80',
    galleryImages: [
      'https://images.unsplash.com/photo-1518091043644-c1d4457512c6?auto=format&fit=crop&w=900&q=80'
    ],
    description: 'Germany’s favorite amateur club jersey. Jako KeepDry technology micro-mesh construction with 5-year availability guarantee.',
    germanDescription: 'Deutschlands beliebtester Teamsport-Klassiker. Jako KeepDry Technologie mit feinstem Polyester-Interlock und 5 Jahren Nachbestellgarantie.',
    sizes: ['116', '128', '140', '152', '164', 'S', 'M', 'L', 'XL', 'XXL', '3XL'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: '100% Recyceltes Jako KeepDry Polyester',
    features: [
      'Jako KeepDry micro-mesh air channels',
      '5-Year guaranteed re-order availability for clubs',
      'Reinforced seams withstand heavy slide tackles'
    ],
    germanFeatures: [
      'Jako KeepDry Technologie leitet Nässe sofort nach außen',
      '5 Jahre garantierte Nachlieferbarkeit für deutsche Vereine',
      'Extrem reißfest und pflegeleicht (60°C waschbar)'
    ],
    isFeatured: true,
    isBestSeller: true,
    clubBulkDiscountEligible: true
  },
  {
    id: 'shirt-derbystar-bundesliga-training',
    name: 'Derbystar Bundesliga Pro Training Tee',
    germanName: 'Derbystar Bundesliga Pro Trainings T-Shirt',
    brand: 'Derbystar',
    category: 'shirts',
    subcategory: 'Teamsport & Training',
    price: 14.95,
    originalPrice: 29.99,
    discountPercentage: 50,
    badge: '⭐ BUNDESLIGA QUALITÄT',
    rating: 4.9,
    reviewsCount: 95,
    image: 'https://images.unsplash.com/photo-1614632537423-1e6c2e7e0aab?auto=format&fit=crop&w=900&q=80',
    galleryImages: [
      'https://images.unsplash.com/photo-1614632537423-1e6c2e7e0aab?auto=format&fit=crop&w=900&q=80'
    ],
    description: 'Official Derbystar training tee by the Bundesliga match ball supplier. Form-retaining fabric with high abrasion resistance.',
    germanDescription: 'Offizielles Trainingsshirt vom Bundesliga-Ausrüster Derbystar. Formstabil, leicht und mit erstklassiger Belüftung.',
    sizes: ['116', '128', '140', '152', '164', 'S', 'M', 'L', 'XL', 'XXL', '3XL'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: '100% Derbystar ClimaTech Polyester',
    features: [
      'Derbystar ClimaTech cooling fabric',
      'Reinforced collar ribbing',
      'Smooth surface for crest and sponsor heat-transfer'
    ],
    germanFeatures: [
      'Derbystar ClimaTech Kühlsystem',
      'Speziell verstärkter Halsausschnitt',
      'Perfekt glatte Textur für DTF-Vereinsdruck'
    ],
    clubBulkDiscountEligible: true
  },
  {
    id: 'shirt-uhlsport-stream-match',
    name: 'Uhlsport Stream Pro Match Shirt',
    germanName: 'Uhlsport Stream Pro Match & Trainings T-Shirt',
    brand: 'Uhlsport',
    category: 'shirts',
    subcategory: 'Teamsport & Training',
    price: 14.95,
    originalPrice: 29.99,
    discountPercentage: 50,
    badge: '🧤 UHLSPORT MATCH',
    rating: 4.8,
    reviewsCount: 88,
    image: 'https://images.unsplash.com/photo-1526676037777-05a232554f77?auto=format&fit=crop&w=900&q=80',
    galleryImages: [
      'https://images.unsplash.com/photo-1526676037777-05a232554f77?auto=format&fit=crop&w=900&q=80'
    ],
    description: 'Uhlsport SmartBreathe technical shirt with breathable raglan cuts for field players and keepers alike.',
    germanDescription: 'Uhlsport SmartBreathe Funktionsshirt mit bewegungsoptimierten Raglanärmeln für Feldspieler und Torhüter.',
    sizes: ['116', '128', '140', '152', '164', 'S', 'M', 'L', 'XL', 'XXL', '3XL'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: '100% SmartBreathe Polyester',
    features: [
      'SmartBreathe ventilation technology',
      'Abrasion-resistant shoulder seams',
      'Available in 10 club colors'
    ],
    germanFeatures: [
      'SmartBreathe Belüftungs-Technologie',
      'Abriebfeste Schulternähte',
      '10 Vereinsfarben für Mannschaften'
    ],
    clubBulkDiscountEligible: true
  },
  {
    id: 'shirt-sportwelt-pro-original',
    name: 'Sportwelt Pro-Match Meister-Trikot 2026',
    germanName: 'Sportwelt Pro-Match Meister-Trikot (Rosenheim Edition)',
    brand: 'Sportwelt',
    category: 'shirts',
    subcategory: 'Teamsport & Training',
    price: 14.95,
    originalPrice: 29.99,
    discountPercentage: 50,
    badge: '⚡ SPORTWELT ORIGINAL',
    rating: 5.0,
    reviewsCount: 310,
    image: 'https://images.unsplash.com/photo-1522778119026-d647f0596c20?auto=format&fit=crop&w=900&q=80',
    galleryImages: [
      'https://images.unsplash.com/photo-1522778119026-d647f0596c20?auto=format&fit=crop&w=900&q=80'
    ],
    description: 'Our in-house flagship functional shirt engineered and customized in Rosenheim, Germany. Ultra-light, anti-cling, and 2-year flock warranty.',
    germanDescription: 'Unser hauseigenes Meisterstück aus unserer Manufaktur in Rosenheim. Höchste Strapazierfähigkeit, kein Verblassen und 2 Jahre Druckgarantie.',
    sizes: ['116', '128', '140', '152', '164', 'S', 'M', 'L', 'XL', 'XXL', '3XL'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: '100% Pro-ClimaPoly Recycled Mesh (145 g/m²)',
    features: [
      'Engineered in Rosenheim, Germany',
      '2-Year warranty on fabric and DTF crest printing',
      '10 vibrant non-fade team colorways'
    ],
    germanFeatures: [
      'Handveredelt in Rosenheim (Deutschland)',
      '2 Jahre Garantie auf Stoff & DTF-Drucke',
      'In allen 10 Vereinsfarben sofort lieferbar'
    ],
    isFeatured: true,
    isBestSeller: true,
    clubBulkDiscountEligible: true
  },

  // --- CLUB TEAMWEAR SETS (VEREINSKOLLEKTIONEN & SETS FÜR DEUTSCHE VEREINE) ---
  {
    id: 'teamwear-15er-satz-meister',
    name: 'Kreisliga & Amateur Komplett-Trikotsatz (15er Pack)',
    germanName: 'Komplett-Trikotsatz für Vereine (14 Feldspieler + 1 Torwart)',
    brand: 'Sportwelt',
    category: 'teamwear',
    subcategory: 'Vereinssets & Club Packs',
    price: 329.00,
    originalPrice: 499.00,
    discountPercentage: 34,
    badge: '🔥 VEREINS-BESTSELLER',
    rating: 5.0,
    reviewsCount: 76,
    image: 'https://images.unsplash.com/photo-1574629810360-7efbbe195018?auto=format&fit=crop&w=900&q=80',
    galleryImages: [
      'https://images.unsplash.com/photo-1574629810360-7efbbe195018?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1518091043644-c1d4457512c6?auto=format&fit=crop&w=900&q=80'
    ],
    description: 'Complete club matchday kit bundle for German amateur and youth teams. Includes 14 player jerseys + shorts + socks, plus 1 padded goalkeeper kit. Includes free individual numbering and club crest printing.',
    germanDescription: 'Das Rundum-Sorglos-Paket für deutsche Amateur- & Jugendmannschaften. Enthält 14 Feldspieler-Trikots + Hosen + Stutzen sowie 1 gepolstertes Torwartset. Inklusive kostenloser Rückennummern (1-15) und Vereinswappen-Druck!',
    sizes: ['Individuelle Größenverteilung (z.B. 4x M, 7x L, 3x XL + 1x TW L)'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: 'Pro-Match ClimaPoly (Reißfest & Atmungsaktiv)',
    features: [
      'Includes 14 Outfield Sets (Shirt + Shorts + Pro Socks)',
      'Includes 1 Full Goalkeeper Set with elbow padding',
      'FREE Back numbers (1-15) + Club Name included in price',
      'Fast delivery in 5-8 business days across Germany'
    ],
    germanFeatures: [
      '14x Feldspieler Komplettset (Trikot + Hose + Stutzen)',
      '1x Torwart-Set mit Ellbogenpolsterung & auffälliger Signalfarbe',
      'Inklusive Rückennummern (1-15) & Vereinsname auf dem Rücken',
      'Kostenlose Musterkoffer-Zusendung zur Größenanprobe möglich',
      'Lieferung innerhalb von 5-8 Werktagen in ganz Deutschland'
    ],
    isFeatured: true,
    isBestSeller: true,
    clubBulkDiscountEligible: true
  },
  {
    id: 'teamwear-youth-starter-pack',
    name: 'Jugendmannschaft Starter-Paket (12er Set)',
    germanName: 'Jako Jugend-Trikotpaket (Bambini bis A-Jugend 12er Set)',
    brand: 'Jako',
    category: 'teamwear',
    subcategory: 'Jugend & Nachwuchs',
    price: 229.00,
    originalPrice: 340.00,
    discountPercentage: 33,
    badge: 'Jugendförderung',
    rating: 4.9,
    reviewsCount: 41,
    image: 'https://images.unsplash.com/photo-1518091043644-c1d4457512c6?auto=format&fit=crop&w=900&q=80',
    galleryImages: [
      'https://images.unsplash.com/photo-1518091043644-c1d4457512c6?auto=format&fit=crop&w=900&q=80'
    ],
    description: 'Designed specifically for youth academies and children/teen teams (sizes 116 to 176). High durability fabric resists aggressive slide tackles on artificial turf.',
    germanDescription: 'Speziell für Jugendmannschaften von F-Jugend bis A-Jugend (Größen 116 bis 176). Extrem strapazierfähiges Material, das Grätschen auf Kunstrasen problemlos standhält.',
    sizes: ['116/128', '140/152', '164/176', 'Mix nach Wunsch'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: 'ToughFlex Eco-Polymer',
    features: [
      'Reinforced seams for wild youth matches',
      'Non-fade sublimation colors withstand 60°C washing',
      'Includes 11 outfield jerseys + 1 goalie jersey'
    ],
    germanFeatures: [
      'Verstärkte Doppelnähte für intensiven Zweikampf',
      'Waschbeständiger Sublimationsdruck (kein Abblättern bei 60°C)',
      '11x Feldspieler + 1x Torwart Trikot'
    ],
    clubBulkDiscountEligible: true
  },
  {
    id: 'ball-derbystar-bundesliga-brillant',
    name: 'Derbystar Bundesliga Brillant APS Matchball',
    germanName: 'Derbystar Bundesliga Brillant APS Offizieller Spielball',
    brand: 'Derbystar',
    category: 'accessories',
    subcategory: 'Offizielle Spielbälle',
    price: 99.95,
    originalPrice: 159.95,
    discountPercentage: 38,
    badge: '🔥 BUNDESLIGA PRO',
    rating: 5.0,
    reviewsCount: 164,
    image: 'https://images.unsplash.com/photo-1614632537423-1e6c2e7e0aab?auto=format&fit=crop&w=900&q=80',
    galleryImages: [
      'https://images.unsplash.com/photo-1614632537423-1e6c2e7e0aab?auto=format&fit=crop&w=900&q=80'
    ],
    description: 'Official Bundesliga Match Ball. Hand-stitched dual-bonded premium casing with diamond texture micro-dimples for zero-wobble trajectories in official championship matches.',
    germanDescription: 'Offizieller Spielball der Bundesliga & 2. Bundesliga. Handgenähte Dual-Bonded Konstruktion mit Diamant-Struktur für absolut flatterfreie Flugbahnen.',
    sizes: ['Größe 5 (Offiziell)'],
    colors: STANDARD_COLORS,
    inStock: true,
    material: 'Hightech-PU mit Diamantstruktur & Naturlatex-Blase',
    features: [
      'FIFA QUALITY PRO Approved',
      'Dual Bonded: hand-sewn and heat-sealed panels',
      'Official ball of the German Bundesliga'
    ],
    germanFeatures: [
      'FIFA QUALITY PRO zertifiziert für höchste Spielklassen',
      'Dual Bonded: handgenäht und zusätzlich thermo-verklebt',
      'Zero-Wing Naturlatexblase für optimale Rundheit'
    ],
    isFeatured: true,
    isBestSeller: true
  }
];

export const TOP_BRANDS = [
  { name: 'Nike', slug: 'Nike', logoText: 'NIKE', color: '#000000' },
  { name: 'adidas', slug: 'adidas', logoText: 'ADIDAS', color: '#000000' },
  { name: 'Puma', slug: 'Puma', logoText: 'PUMA', color: '#000000' },
  { name: 'Jako', slug: 'Jako', logoText: 'JAKO', color: '#0047BA' },
  { name: 'Erima', slug: 'Erima', logoText: 'ERIMA', color: '#E30613' },
  { name: 'Derbystar', slug: 'Derbystar', logoText: 'DERBYSTAR', color: '#000000' },
  { name: 'Uhlsport', slug: 'Uhlsport', logoText: 'UHLSPORT', color: '#000000' },
  { name: 'Sportwelt', slug: 'Sportwelt', logoText: 'SPORTWELT PRO', color: '#059669' }
];

export const CLUB_PRESET_CRESTS = [
  { id: 'crest-eagle', name: 'SV Adler (Klassisch)', icon: '🦅', color: '#1E3A8A' },
  { id: 'crest-lion', name: 'FC Löwen (Mut & Kraft)', icon: '🦁', color: '#DC2626' },
  { id: 'crest-shield-gold', name: 'DJK Borussia Schild', icon: '🛡️', color: '#CA8A04' },
  { id: 'crest-star', name: 'Stern 1920 e.V.', icon: '⭐', color: '#16A34A' },
  { id: 'crest-ball', name: 'Kickers United', icon: '⚽', color: '#0F172A' },
  { id: 'crest-crown', name: 'VfB Viktoria', icon: '👑', color: '#7C3AED' }
];

export const SAMPLE_CLUB_LOGOS = [
  {
    id: 'logo-sportwelt-default',
    name: 'Sportwelt Offiziell (Standard)',
    preview: '⚡ SPORTWELT',
    subtitle: 'Fußball & Teamsport Deutschland'
  }
];
