import React, { useState } from 'react';
import { X, CheckCircle2, Building2, Truck, CreditCard, ShieldCheck, Lock, AlertCircle } from 'lucide-react';
import { CartItem, Language } from '../types';
import confetti from 'canvas-confetti';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  items?: CartItem[];
  cart?: CartItem[];
  total?: number;
  lang: Language;
  onClearCart?: () => void;
  onSuccess?: () => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  items,
  cart,
  total: propTotal,
  lang,
  onClearCart,
  onSuccess
}) => {
  const [step, setStep] = useState<'form' | 'success'>('form');
  const [paymentMethod, setPaymentMethod] = useState<'paypal' | 'card'>('paypal');
  const [orderNumber, setOrderNumber] = useState('');

  const [form, setForm] = useState({
    clubName: '',
    firstName: '',
    lastName: '',
    email: '',
    street: '',
    zip: '',
    city: '',
    phone: '',
    cardNumber: '',
    cardExpiry: '',
    cardCvc: '',
    cardHolder: '',
    notes: ''
  });

  if (!isOpen) return null;

  const checkoutItems: CartItem[] = items || cart || [];
  const subtotal = checkoutItems.reduce((sum, item) => sum + (item.totalPrice || 0), 0);
  const shipping = subtotal >= 50 || subtotal === 0 ? 0 : 4.95;
  const calculatedTotal = subtotal + shipping;
  const total = typeof propTotal === 'number' && propTotal > 0 ? propTotal : calculatedTotal;

  const MIN_ORDER_VALUE = 89.00;
  const hasMetMinOrder = subtotal >= MIN_ORDER_VALUE;
  const missingAmount = Math.max(0, MIN_ORDER_VALUE - subtotal);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!hasMetMinOrder) return;
    const generatedOrder = `SW-DE-${Math.floor(100000 + Math.random() * 900000)}`;
    setOrderNumber(generatedOrder);
    setStep('success');
    confetti({
      particleCount: 100,
      spread: 80,
      origin: { y: 0.5 }
    });
    if (onClearCart) onClearCart();
    if (onSuccess) onSuccess();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/65 backdrop-blur-sm p-4 overflow-y-auto animate-in fade-in duration-200">
      <div 
        id="checkout-modal"
        className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-slate-100 relative my-8"
      >
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-700 transition"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {step === 'form' ? (
          <div>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-black">
                ⚽
              </div>
              <div>
                <h3 className="text-xl font-black text-slate-900">
                  {lang === 'de' ? 'Sportwelt Express-Kasse' : 'Sportwelt Checkout'}
                </h3>
                <p className="text-xs text-slate-500">
                  {lang === 'de' ? 'Lieferung innerhalb Deutschlands (3-6 Werktage via DHL)' : 'Shipping within Germany (3-6 days via DHL)'}
                </p>
              </div>
            </div>

            {!hasMetMinOrder && (
              <div className="mb-5 p-4 rounded-2xl bg-amber-50 border border-amber-200 text-amber-950 flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                <div className="text-xs">
                  <strong className="block font-bold mb-0.5">
                    {lang === 'de' ? 'Mindestbestellwert von 89,00 € noch nicht erreicht' : 'Minimum order value of €89.00 not reached'}
                  </strong>
                  <span>
                    {lang === 'de'
                      ? `Der Mindestbestellwert für den Kassenbereich beträgt 89,00 €. Ihr aktueller Warenkorb liegt bei ${subtotal.toFixed(2)} € (Es fehlen noch ${missingAmount.toFixed(2)} €).`
                      : `The minimum order amount is €89.00. Your cart subtotal is €${subtotal.toFixed(2)} (Missing €${missingAmount.toFixed(2)}).`}
                  </span>
                  <div className="mt-2">
                    <button
                      type="button"
                      onClick={onClose}
                      className="px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs transition"
                    >
                      {lang === 'de' ? 'Zurück zum Warenkorb / Weiter shoppen' : 'Back to Cart / Continue Shopping'}
                    </button>
                  </div>
                </div>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Optional Club Name */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  {lang === 'de' ? 'Vereinsname (Optional bei Vereinsbestellung)' : 'Club Name (Optional for football teams)'}
                </label>
                <div className="relative">
                  <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    value={form.clubName}
                    onChange={(e) => setForm({ ...form, clubName: e.target.value })}
                    placeholder="z.B. SV Vorwärts 1919 e.V."
                    className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:ring-1 focus:ring-emerald-500"
                  />
                </div>
              </div>

              {/* Name fields */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Vorname *
                  </label>
                  <input
                    type="text"
                    required
                    value={form.firstName}
                    onChange={(e) => setForm({ ...form, firstName: e.target.value })}
                    placeholder="Michael"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:ring-1 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Nachname *
                  </label>
                  <input
                    type="text"
                    required
                    value={form.lastName}
                    onChange={(e) => setForm({ ...form, lastName: e.target.value })}
                    placeholder="Schmidt"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:ring-1 focus:ring-emerald-500"
                  />
                </div>
              </div>

              {/* Contact info */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    E-Mail-Adresse für Bestellbestätigung *
                  </label>
                  <input
                    type="email"
                    required
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    placeholder="bestellung@fussballverein.de"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:ring-1 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Telefonnummer (für DHL Sendungsverfolgung)
                  </label>
                  <input
                    type="tel"
                    value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })}
                    placeholder="0172 / 1234567"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:ring-1 focus:ring-emerald-500"
                  />
                </div>
              </div>

              {/* Address in Germany */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Straße &amp; Hausnummer *
                  </label>
                  <input
                    type="text"
                    required
                    value={form.street}
                    onChange={(e) => setForm({ ...form, street: e.target.value })}
                    placeholder="Sportplatzweg 12"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:ring-1 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    PLZ *
                  </label>
                  <input
                    type="text"
                    required
                    value={form.zip}
                    onChange={(e) => setForm({ ...form, zip: e.target.value })}
                    placeholder="44137"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:ring-1 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Stadt / Ort in Deutschland *
                </label>
                <input
                  type="text"
                  required
                  value={form.city}
                  onChange={(e) => setForm({ ...form, city: e.target.value })}
                  placeholder="Dortmund"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              {/* Payment Methods - Exclusively PayPal and Kreditkarte */}
              <div className="pt-2">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                  Zahlungsart wählen
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {[
                    { 
                      id: 'paypal', 
                      label: 'PayPal', 
                      badge: 'Käuferschutz & Express', 
                      icon: (
                        <span className="font-black text-sm text-[#003087] bg-blue-100 px-2 py-0.5 rounded-md">
                          Pay<span className="text-[#0079C1]">Pal</span>
                        </span>
                      ),
                      desc: 'Schnell & sicher mit Ihrem PayPal-Konto bezahlen' 
                    },
                    { 
                      id: 'card', 
                      label: 'Kreditkarte', 
                      badge: 'Visa / Mastercard / Amex', 
                      icon: <CreditCard className="w-5 h-5 text-emerald-600" />,
                      desc: '256-Bit SSL-verschlüsselte Kartenzahlung' 
                    }
                  ].map((pm) => (
                    <button
                      key={pm.id}
                      type="button"
                      onClick={() => setPaymentMethod(pm.id as any)}
                      className={`p-3.5 rounded-2xl border text-left flex flex-col justify-between transition relative ${
                        paymentMethod === pm.id
                          ? 'border-emerald-600 bg-emerald-50/70 text-slate-900 ring-2 ring-emerald-600 shadow-sm'
                          : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      <div className="flex items-center justify-between w-full mb-1">
                        <div className="flex items-center gap-2">
                          {pm.icon}
                          <span className="text-sm font-black">{pm.label}</span>
                        </div>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100/80 text-emerald-800 border border-emerald-200">
                          {pm.badge}
                        </span>
                      </div>
                      <span className="text-[11px] text-slate-500 mt-1 leading-snug">{pm.desc}</span>
                    </button>
                  ))}
                </div>

                {/* Sub-panels for selected payment method */}
                {paymentMethod === 'paypal' && (
                  <div className="mt-3 p-3.5 bg-blue-50/60 border border-blue-200 rounded-2xl flex items-center gap-3">
                    <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold text-sm shrink-0">
                      P
                    </div>
                    <div className="text-xs text-blue-950 leading-relaxed">
                      <strong className="block font-bold">PayPal Käuferschutz aktiv</strong>
                      Nach Klick auf „Kostenpflichtig bestellen“ wirst du verschlüsselt zu PayPal weitergeleitet, um die Zahlung abzuschließen.
                    </div>
                  </div>
                )}

                {paymentMethod === 'card' && (
                  <div className="mt-3 p-3.5 bg-slate-50 border border-slate-200 rounded-2xl space-y-2.5 animate-in fade-in duration-200">
                    <div className="flex items-center justify-between text-xs font-bold text-slate-700">
                      <div className="flex items-center gap-1.5">
                        <Lock className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Kreditkartendaten (SSL-gesichert)</span>
                      </div>
                      <span className="text-[10px] text-slate-400 font-medium">Visa • Mastercard • Amex</span>
                    </div>

                    <div>
                      <input
                        type="text"
                        required={paymentMethod === 'card'}
                        value={form.cardNumber}
                        onChange={(e) => {
                          const val = e.target.value.replace(/\D/g, '').substring(0, 16);
                          const formatted = val.match(/.{1,4}/g)?.join(' ') || val;
                          setForm({ ...form, cardNumber: formatted });
                        }}
                        placeholder="Kartennummer (z.B. 4532 •••• •••• 8910)"
                        className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 font-mono tracking-wider focus:ring-1 focus:ring-emerald-500"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <input
                        type="text"
                        required={paymentMethod === 'card'}
                        value={form.cardExpiry}
                        onChange={(e) => {
                          let val = e.target.value.replace(/\D/g, '').substring(0, 4);
                          if (val.length >= 3) {
                            val = `${val.substring(0, 2)}/${val.substring(2)}`;
                          }
                          setForm({ ...form, cardExpiry: val });
                        }}
                        placeholder="MM / YY"
                        className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 font-mono text-center focus:ring-1 focus:ring-emerald-500"
                      />
                      <input
                        type="password"
                        maxLength={4}
                        required={paymentMethod === 'card'}
                        value={form.cardCvc}
                        onChange={(e) => setForm({ ...form, cardCvc: e.target.value.replace(/\D/g, '') })}
                        placeholder="CVC / CVV"
                        className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 font-mono text-center focus:ring-1 focus:ring-emerald-500"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Total & Submit */}
              <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div>
                  <span className="text-xs text-slate-500">Gesamtbetrag (inkl. 19% MwSt.)</span>
                  <div className="text-2xl font-black text-slate-950">{total.toFixed(2)} €</div>
                </div>

                <button
                  type="submit"
                  disabled={!hasMetMinOrder}
                  className={`w-full sm:w-auto px-8 py-3.5 rounded-xl font-black text-sm shadow-xl transition flex items-center justify-center gap-2 ${
                    hasMetMinOrder
                      ? 'bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer'
                      : 'bg-slate-200 text-slate-400 border border-slate-300 cursor-not-allowed select-none shadow-none'
                  }`}
                >
                  {hasMetMinOrder ? (
                    <CheckCircle2 className="w-4 h-4" />
                  ) : (
                    <Lock className="w-4 h-4 text-slate-400" />
                  )}
                  <span>
                    {!hasMetMinOrder
                      ? (lang === 'de' ? `Mindestbestellwert 89,00 € (noch ${missingAmount.toFixed(2)} €)` : `Min. €89.00 required (€${missingAmount.toFixed(2)} left)`)
                      : paymentMethod === 'paypal' ? 'Mit PayPal bezahlen' : 'Mit Kreditkarte bezahlen'}
                  </span>
                </button>
              </div>
            </form>
          </div>
        ) : (
          /* Order Confirmation Screen */
          <div className="py-8 text-center space-y-4 animate-in fade-in duration-300">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto text-3xl shadow-sm">
              🎉
            </div>
            <h3 className="text-2xl font-black text-slate-900">
              Vielen Dank für deine Bestellung bei Sportwelt!
            </h3>
            <div className="inline-block p-3 rounded-xl bg-slate-100 text-slate-800 font-mono text-sm font-bold">
              Bestellnummer: {orderNumber}
            </div>
            <p className="text-xs text-slate-600 max-w-md mx-auto leading-relaxed">
              Wir haben die Auftragsbestätigung und den Zahlungsbeleg ({paymentMethod === 'paypal' ? 'PayPal' : 'Kreditkarte'}) an <strong>{form.email || 'deine E-Mail'}</strong> gesendet. Deine Artikel werden sorgfältig kommissioniert und via DHL zugestellt.
            </p>

            <div className="p-4 bg-emerald-50 border border-emerald-100 rounded-2xl max-w-md mx-auto text-left text-xs text-emerald-900 space-y-1.5">
              <div className="font-bold flex items-center gap-1.5">
                <Truck className="w-4 h-4 text-emerald-600" />
                <span>Lieferadresse &amp; Zahlung:</span>
              </div>
              <div>{form.clubName && `${form.clubName} • `}{form.firstName} {form.lastName}</div>
              <div>{form.street}, {form.zip} {form.city} (Deutschland)</div>
              <div className="pt-1 text-[11px] text-emerald-700 font-semibold">
                Zahlungsart: {paymentMethod === 'paypal' ? 'PayPal (Express)' : 'Kreditkarte (Visa/Mastercard)'} • Status: Bezahlt
              </div>
            </div>

            <div className="pt-4">
              <button
                type="button"
                onClick={onClose}
                className="px-6 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs transition"
              >
                Zurück zum Shop
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
